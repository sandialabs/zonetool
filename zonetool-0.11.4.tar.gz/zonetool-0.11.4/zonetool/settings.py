#    Zonetool is a utility for signing and maintaining DNSSEC zones and keys.
#
#    Copyright (2009) Sandia Corporation. Under the terms of Contract
#    DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
#    certain rights in this software.
#
#    This package is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This package is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License along
#    with this program; if not, write to the Free Software Foundation, Inc.,
#    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

import ConfigParser
import os

from errors import ZoneToolError

class SettingsError(ZoneToolError):
    pass

values = {
    'global': {
        'named_user': 'bind',
        'named_group': 'bind',
        'zonetool_cfg': '/etc/zonetool/zonetool.cfg',
        'zonetool_dir': '/var/lib/zonetool',
        'named_conf': '/etc/bind/named.conf',
        'chroot': '',
        'randomdev': '',
        'default_view': '',
        'quiet': 'no',
        'propagation_time': 60,
        'gen_ds_rrs': 'no',
        'ksk_update_style': 'manual',
        'dlv_domain': '',
        'publish_all_ksks_in_view': '',
        'dnskey_ttl': '',
        'nsec3param_ttl': '',
    },
    'reporting': {
        'send_email_report': 'yes',
        'log_to_syslog': 'yes',
        'smtp_host': 'localhost',
        'mail_from': 'Zone manager <zonetool>',
        'mail_to': 'root',
        'mail_subject': 'DNS zone maintenance report',
        'syslog_facility': 'user',
    },
    'maintenance': {
        'sig_renewal_window': 7,
        'zsk_expiration': 30,
        'ksk_expiration': 365,
    },
}

def update_values(**kwargs):
    filename = kwargs.get('global', {}).get('zonetool_cfg', None)
    if filename is not None:
        if not os.path.exists(filename):
            raise SettingsError('Unable to read config file %s does not exist!' % filename)
    else:
        filename = values['global'].get('zonetool_cfg', None)
        if not os.path.exists(filename):
            filename = None

    if filename is not None:
        if not os.access(filename, os.R_OK):
            raise SettingsError('Unable to read config file %s.  Insufficient permissions!' % filename)
        cp = ConfigParser.SafeConfigParser()
        cp.read(filename)
        for section in values.keys():
            if not cp.has_section(section):
                cp.add_section(section)
            for option in cp.options(section):
                values[section][option] = cp.get(section,option)

    for section in values.keys():
        values[section].update(kwargs.get(section, {}))
