#    Zonetool is a utility for signing and maintaining DNSSEC zones and keys.
#
#    Copyright (2009) Sandia Corporation. Under the terms of Contract
#    DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
#    certain rights in this software.
#
#    This package is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This package is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License along
#    with this program; if not, write to the Free Software Foundation, Inc.,
#    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

import datetime
import grp
import pwd
import logging
import os
import random
import re
import shutil
import signal
import stat
import sys
import tempfile
import time

from dnssec_util import DNSKEY_SUFFIXES, DNSKEY_ALGORITHMS, DNSKEY_PROTOCOLS, \
        strip_key_suffix, canonicalize_name, gen_zsk, gen_ksk
from errors import ZoneToolError
from NamedConf import NamedConf
import settings
from util import CommandError, check_named_conf, dig_query, serial_for_zone, \
        rndc_freeze, rndc_thaw, rndc_reload_conf, selinux_restorecon, selinux_enabled, \
        parent, chroot_relative_path, ensure_dir_exists, zone_str, daemonize
from zone import DEFAULT_VIEW, ZoneError, StateTransitionError, InconsistentKeys, StateNotExpired, \
        LogError, LogWriteError, LogDoesNotExist, LogLockError, \
        Zone, ZoneState, ZoneLog, DNSSECKey
from log import logger, console_logger, flush_handler, set_handler_log_level, disable_handler

ROOT_ZONE_REPR = 'root'
ZONE_LOG_FILE = 'log'
ZONE_LOG_VERSION = 2
ZONE_LOG_VERSION_FILE = 'log_version'
ARCHIVE_DIR = 'archive'

class ConfigurationError(ZoneToolError):
    pass

class InteractionNeeded(ZoneToolError):
    pass

class MaintenanceNeeded(ZoneToolError):
    pass

class LogVersionError(LogError):
    def __init__(self, msg, old_version=None):
        LogError.__init__(self, msg)
        self.old_version = old_version

class ZoneNotManaged(ZoneToolError):
    pass

class ZoneManager(object):
    def __init__(self):
        # ensure that zonetool.cfg is readable
        named_conf = settings.values['global'].get('named_conf', None)
        default_view = settings.values['global'].get('default_view', None)
        zonetool_dir = settings.values['global'].get('zonetool_dir', None)
        named_user = settings.values['global'].get('named_user', None)
        named_group = settings.values['global'].get('named_group', None)
        chroot = settings.values['global'].get('chroot', None)
        randomdev = settings.values['global'].get('randomdev', None)
        ksk_update_style = settings.values['global'].get('ksk_update_style', 'manual')
        gen_ds_rrs = settings.values['global'].get('gen_ds_rrs', 'yes').lower() not in ('no','false')
        publish_all_ksks_in_view = settings.values['global'].get('publish_all_ksks_in_view', None)
        propagation_time = settings.values['global'].get('propagation_time', None)
        dlv_domain = settings.values['global'].get('dlv_domain', None)
        nsec3param_ttl = settings.values['global'].get('nsec3param_ttl', None)
        dnskey_ttl = settings.values['global'].get('dnskey_ttl', None)

        if not named_conf:
            raise ConfigurationError('The path to named.conf must be specified when creating a ZoneManager instance')
        if not os.path.isabs(named_conf):
            raise ConfigurationError('The path to named.conf must be absolute: %s' % named_conf)
        if not zonetool_dir:
            raise ConfigurationError('The path to the zonetool directory must be specified when creating a ZoneManager instance')
        if not named_user:
            raise ConfigurationError('The user for the name daemon must be specified when creating a ZoneManager instance')
        if not named_group:
            raise ConfigurationError('The group for the name daemon must be specified when creating a ZoneManager instance')

        # if not specified, chroot should be and empty string
        if chroot and not os.path.isabs(chroot):
            raise ConfigurationError('The path to chroot must be absolute: %s' % chroot)
        if chroot is None:
            chroot = ''

        # if some vars are empty strings, they should be None
        if not randomdev:
            randomdev = None
        if not default_view:
            default_view = None
        if not publish_all_ksks_in_view:
            publish_all_ksks_in_view = None

        self.named_conf = named_conf
        self.default_view = default_view
        self.zonetool_dir = zonetool_dir
        self.chroot = chroot.rstrip(os.sep)
        self.randomdev = randomdev
        self.ksk_update_style = ksk_update_style
        self.gen_ds_rrs = gen_ds_rrs
        self.publish_all_ksks_in_view = publish_all_ksks_in_view
        try:
            self.propagation_time = int(propagation_time)
        except ValueError:
            self.propagation_time = 0
        self.dlv_domain = dlv_domain

        # check existence/readability of dirs
        self.dir_readable(self.zonetool_dir)
        self.file_readable(self.chroot + self.named_conf)
        if self.randomdev is not None:
            self.file_readable(self.randomdev)

        # Get named user and group
        try:
            self.named_uid = pwd.getpwnam(named_user)[2]
        except KeyError:
            raise ConfigurationError('User "%s" does not exist' % named_user)
        try:
            self.named_gid = grp.getgrnam(named_group)[2]
        except KeyError:
            raise ConfigurationError('Group "%s" does not exist' % named_group)

        try:
            self.named_conf_obj = NamedConf(self.named_conf, self.chroot)
        except CommandError, e:
            raise ConfigurationError('Error parsing named.conf: %s' % str(e))

        for key in ('nsec3param_ttl', 'dnskey_ttl'):
            val = settings.values['global'].get(key, None)
            if not val:
                continue
            try:
                if int(val) < 0:
                    raise ValueError()
            except ValueError:
                raise ConfigurationError('Invalid value for %s: %s' % (key, val))

        # get the maintenance defaults
        for key in ('sig_renewal_window', 'zsk_expiration', 'ksk_expiration'):
            val = settings.values['maintenance'].get(key, None)
            try:
                setattr(self, key, datetime.timedelta(int(val)))
            except ValueError:
                raise ConfigurationError('Invalid value for %s: %s' % (key, str(val)))

        self.maintenance_alarm = None
        self._zone_cache = {}
        self._zone_log_cache = {}

    def file_readable(self, path, title=''):
        if title:
            title += ': '
        perms = os.R_OK
        if not (os.path.exists(path) and \
                os.access(path, perms)):
            raise ConfigurationError('%s%s does not exist or is not readable!' % (title, path))

    def dir_readable(self, path, title=''):
        if title:
            title += ': '
        perms = os.R_OK|os.X_OK
        if not (os.path.isdir(path) and \
                os.access(path, perms)):
            raise ConfigurationError('%s%s does not exist or is not readable!' % (title, path))

    def archive_key(self, key_obj, zone):
        '''Archive key_file to the archive directory.'''

        # create the directory for archiving the key
        now = time.localtime()
        archive_dir = zone.meta_directory
        for subdir in (ARCHIVE_DIR, time.strftime('%Y', now), time.strftime('%m', now)):
            archive_dir = os.path.join(archive_dir, subdir)

        try:
            ensure_dir_exists(archive_dir)
        except OSError, e:
            raise ConfigurationError('Unable to archive %s: %s' % (key_obj, e))

        # strip any suffixes from the key files
        src_base = strip_key_suffix(key_obj.file)
        dst_base = os.path.join(archive_dir, key_obj.filename())

        # copy existing keys to keys directory
        for ext in DNSKEY_SUFFIXES:
            src = src_base+ext
            dst = dst_base+ext

            try:
                console_logger.debug('mv %s %s' % (src,dst))
                shutil.move(src,dst)
            except IOError, e:
                raise ConfigurationError('Unable to archive %s: %s' % (key_obj, e))

            # restore SELinux context, if applicable
            if os.uname()[0] == 'Linux':
                try:
                    selinux_restorecon(dst)
                except CommandError, e:
                    if selinux_enabled():
                        logger.warn('Unable to restore SELinux context of archived key %s: %s' % (dst, e))

        key_obj.file = dst_base

    def chroot_relative(self, path):
        return chroot_relative_path(path, self.chroot)

    def zone_dir(self, origin, view, create=False):
        # canonicalize origin and view for consistency
        origin = canonicalize_name(origin)
        if origin == '.':
            origin = ROOT_ZONE_REPR
        else:
            origin = origin.rstrip('.')
        if view:
            view = view.lower()
        else:
            view = DEFAULT_VIEW

        zone_dir = self.zonetool_dir
        for subdir in (origin, view):
            zone_dir = os.path.join(zone_dir, subdir)
            if not os.path.exists(zone_dir) and create:
                try:
                    os.mkdir(zone_dir, 0755)
                except OSError, e:
                    raise ConfigurationError('Unable to create zone directory for %s: %s' % (origin, e))

        return zone_dir

    def _check_zone_log_version(self, origin, cls='IN', view=None, create=False):
        log_version_file = os.path.join(self.zone_dir(origin, view), ZONE_LOG_VERSION_FILE)
        if not os.path.exists(log_version_file):
            if not create:
                raise LogVersionError('Log version file %s for %s does not exist' % (log_version_file, zone_str(origin, cls, view)))
            try:
                ensure_dir_exists(os.path.dirname(log_version_file))
                open(log_version_file, 'w').write('%d' % ZONE_LOG_VERSION)
            except (OSError, IOError), e:
                raise ConfigurationError('Unable to create log version file %s for %s: %s' (log_version_file, zone_str(origin, cls, view), e))
        else:
            try:
                log_version = int(open(log_version_file).read().strip())
            except (IOError, ValueError), e:
                raise ConfigurationError('Unable to extract log version for %s from %s: %s' % (zone_str(origin, cls, view), log_version_file, e))
            if log_version != ZONE_LOG_VERSION:
                raise LogVersionError('Version of log file for %s (%d) does not match current zone log version (%d)' % \
                        (zone_str(origin, cls, view), log_version, ZONE_LOG_VERSION), log_version)

    def get_zone_log(self, origin, cls='IN', view=None, write=False, create=False, cache=True):
        origin = canonicalize_name(origin)
        if self._zone_log_cache.has_key((origin,cls,view)):
            zone_log = self._zone_log_cache[(origin,cls,view)]
        else:
            zone_log = ZoneLog(os.path.join(self.zone_dir(origin, view), ZONE_LOG_FILE))

        try:
            zone_log.initialize_handle(write, create)

            # check zone log version
            self._check_zone_log_version(origin, cls, view, create)

            # check for a current state in the log file
            zone_state = zone_log.current_state()
            if zone_state is None and not create:
                raise ZoneNotManaged('Zone %s is not managed.' % zone_str(origin, cls, view))

            if cache:
                self._zone_log_cache[(origin,cls,view)] = zone_log
            return zone_log

        except LogLockError:
            # check zone log version before continuing in the exception
            # handler; otherwise it will fail with an incompatible version
            self._check_zone_log_version(origin, cls, view, create)

            # give a more useful error message about the state of the zone,
            # if the zone log file was locked by another process
            zone_log = ZoneLog(os.path.join(self.zone_dir(origin, view), ZONE_LOG_FILE))
            zone_log.initialize_handle(write=False, create=False)
            zone_state = zone_log.current_state()
            if zone_state is not None:
                raise LogLockError('Zone %s is being maintenanced by another process, currently in state "%s" until at least %s' % \
                        (zone_str(origin, cls, view), zone_state.name, time.strftime('%x %X', zone_state.expire)))

            # if we couldn't determine a state, then
            # re-raise the same exception
            raise

        except LogDoesNotExist:
            raise ZoneNotManaged('Zone %s is not managed.' % zone_str(origin, cls, view))

    def get_zone(self, origin, cls='IN', view=None, write=False, create=False, no_freeze=False, cache=True):
        zone_title = zone_str(origin, cls, view)
        origin = canonicalize_name(origin)

        # check that the zone statement exists in the named.conf
        zone_obj = self.named_conf_obj.get_zone(origin, cls, view)
        if zone_obj is None:
            raise ConfigurationError('Zone %s of %s not found' % (zone_title, self.named_conf))

        # check that the zone is a master zone
        # (this is allowed if read_only is True)
        zone_type = self.named_conf_obj.zone_type(origin, cls, view)
        if not (zone_type is not None and zone_type.lower() == 'master') and write:
            raise ConfigurationError('Zone %s of %s is not a master zone' % (zone_title, self.named_conf))

        # check that there is a file for the zone in named.conf
        zone_file = self.named_conf_obj.zone_file(origin, cls, view)
        if zone_file is None:
            raise ConfigurationError('Zone file for %s of not found in %s' % (zone_title, self.named_conf))

        # find out if the zone is dynamic (i.e., allows updates);
        # if it is, ensure that a key-directory exists for the zone
        # in named.conf, and that the directory is not the same as
        # zonetool's zone directory
        is_dynamic = self.named_conf_obj.is_dynamic(origin, cls, view)
        key_dir = self.named_conf_obj.zone_key_dir(origin, cls, view)

        zone_dir = self.zone_dir(origin, view, create)
        if write and is_dynamic and not no_freeze:
            try:
                rndc_freeze(origin, view)
            except CommandError, e:
                raise ZoneError('Unable to freeze %s: %s' % (zone_title, e))
        try:
            if self._zone_cache.has_key((origin,cls,view)):
                zone = self._zone_cache[(origin,cls,view)]
                zone.refresh_zone_info()
            else:
                zone = Zone(origin, cls, view, zone_file, key_dir, is_dynamic, zone_dir, chroot=self.chroot,
                        dnskey_ttl=settings.values['global'].get('dnskey_ttl', None), nsec3param_ttl=settings.values['global'].get('nsec3param_ttl', None))
        finally:
            if write and is_dynamic and not no_freeze:
                try:
                    rndc_thaw(origin, view)
                except CommandError, e:
                    raise ZoneError('Unable to thaw %s: %s' % (zone_title, e))

        if write:
            if zone.is_signed and not zone.is_dynamic:
                if not (zone.unsigned_zone_file is not None and os.path.exists(zone.unsigned_zone_file)):
                    raise ConfigurationError('Unable to detect unsigned zone file for %s with zone file %s.' % (zone, zone.zone_file))
                if zone.unsigned_serial is None:
                    raise ConfigurationError('Unable to determine serial of unsigned version of %s with zone file %s.' % (zone, zone.zone_file))

        if cache:
            self._zone_cache[(origin,cls,view)] = zone
        included_ksks = self.published_ksks_from_other_views(zone, include_all=True)
        zone.remove_published_ksks(included_ksks)
        return zone

    def get_zone_ds(self, origin, current_zone=None):
        origin = canonicalize_name(origin)

        # check that the zone statement exists in the named.conf
        if not self.named_conf_obj.zones.has_key(origin):
            raise ConfigurationError('No zone with origin %s found in %s' % (origin, self.named_conf))

        ds_str = ';;;;; Begin DS RRset for %s ;;;;;\n' % origin
        dnskey_str = ';;;;; Begin DNSKEY RRset for %s ;;;;;\n' % origin
        for cls, view in self.named_conf_obj.zones[origin]:
            zone_type = self.named_conf_obj.zone_type(origin,cls,view)
            if zone_type is None or zone_type.lower() != 'master':
                continue

            managed = True
            try:
                zone_log = self.get_zone_log(origin, view=view)
                zone_state = zone_log.current_state()
            except ZoneNotManaged:
                managed = False
            except LogError, e:
                logger.error('Unreadable log file for %s: %s' % (zone_str(origin, 'IN', view), e))
                continue

            if current_zone is not None and view == current_zone.view:
                zone = current_zone
            else:
                zone = self.get_zone(origin, view=view)
            if not managed:
                if zone.is_signed:
                    logger.warning('%s is not managed by zonetool; its DS RRs will not be included in the DS RRSet for %s, which may cause DNSSEC validation for %s to fail' % (zone, origin, zone))
                else:
                    logger.warning('%s is not signed; if %s includes DS RRs for %s, DNSSEC validation for %s may fail' % (zone, parent(zone.origin), origin, zone))
                continue

            zone_state.check_keys(zone)
            
            # open the DS file, and distinguish the old from the new
            ds_file = os.path.join(zone.meta_directory, 'dsset-'+zone.origin)
            try:
                ds_file_fh = open(ds_file)
            except IOError, e:
                raise ConfigurationError('Unable to read DSset file %s for %s: %s' % (ds_file, zone, e))

            ds_str += '; DS RRs for %s\n' % zone
            dnskey_str += '; DNSKEY RRs for %s\n' % zone
            if zone_state.name in ('ksk-dsroll-wait-dschange', 'ksk-dsroll-wait-dsttl', 'alg-roll-wait-dschange', 'alg-roll-wait-dsttl'):
                # find out which key was published last
                pub0,act0 = zone_log.key_info(zone.active_ksks[0].filename())
                pub1,act1 = zone_log.key_info(zone.active_ksks[1].filename())
                if pub0 < pub1:
                    i = 1
                else:
                    i = 0
                ksk_objs = [zone.active_ksks[i]]
            else:
                ksk_objs = zone.active_ksks

            found_ds = False
            for line in ds_file_fh:
                name, cls, rrtype, key_id, algorithm, rest = line.split(None, 5)
                key_id = int(key_id)
                algorithm = int(algorithm)
                ds_key_obj = DNSSECKey(name, None, DNSKEY_PROTOCOLS['DNSSEC'], algorithm, key_tag=key_id)
                if ds_key_obj in ksk_objs:
                    ds_str += line
                    found_ds = True

            if not found_ds:
                ConfigurationError('Could not identify DS in %s' % ds_file)

            for ksk in ksk_objs:
                dnskey_str += ksk.rr()+'\n'

        ds_str += ';;;;; End DS RRset for %s ;;;;;\n' % origin
        dnskey_str += ';;;;; End DNSKEY RRset for %s ;;;;;\n' % origin

        return ds_str, dnskey_str

    def published_ksks_from_other_views(self, zone, include_all=False):
        # there is only one view
        if zone.view is None:
            return []
        # there are multiple views, but this isn't the one specified
        if not include_all and self.publish_all_ksks_in_view != zone.view:
            return []
        # this is a short-cut; if included_all is True, then we are
        # running this to determine which keys should be stripped--not
        # determining which should be included with the zone
        if include_all and len(zone.active_ksks) <= 1:
            return []

        keys_to_include = []
        for cls, other_view in self.named_conf_obj.zones[zone.origin]:
            zone_type = self.named_conf_obj.zone_type(zone.origin,cls,other_view)
            if zone_type is None or zone_type.lower() != 'master':
                continue

            if other_view == zone.view:
                continue

            managed = True
            try:
                zone_log = self.get_zone_log(zone.origin, view=other_view)
                zone_state = zone_log.current_state()
            except ZoneNotManaged:
                managed = False
            except LogError, e:
                logger.error('Unreadable log file for %s: %s' % (zone_str(zone.origin, 'IN', other_view), e))
                continue

            # look in cache first to avoid a recursive loop, since get_zone calls published_ksks_from_other_views
            if self._zone_cache.has_key((zone.origin, 'IN', other_view)):
                other_zone = self._zone_cache[(zone.origin,'IN',other_view)]
            else:
                other_zone = self.get_zone(zone.origin, view=other_view)
            if not managed:
                if not include_all:
                    logger.warning('Unable to publish active KSKs of %s in %s because %s is not managed by Zonetool' % (other_zone, zone, other_zone))
                continue

            zone_state.check_keys(other_zone)
            
            active_ksks_from_other_zone = []
            if not include_all and \
                    zone_state.name in ('ksk-dsroll-wait-dschange', 'ksk-dsroll-wait-dsttl', 'alg-roll-wait-dschange', 'alg-roll-wait-dsttl'):
                # find out which key was published last
                pub0,act0 = zone_log.key_info(other_zone.active_ksks[0].filename())
                pub1,act1 = zone_log.key_info(other_zone.active_ksks[1].filename())
                if pub0 < pub1:
                    i = 1
                else:
                    i = 0

                active_ksks_from_other_zone = [other_zone.active_ksks[i]]
            else:
                active_ksks_from_other_zone = other_zone.active_ksks

            # check the algorithm of the key being included. there must 
            for ksk in active_ksks_from_other_zone:
                if ksk.algorithm in [zsk.algorithm for zsk in zone.active_zsks]:
                    keys_to_include.append(ksk)
                else:
                    logger.warning('Unable to publish active KSK %s from %s because it there is no ZSK with the corresponding algorithm in %s' % (ksk, other_zone, zone))

        return keys_to_include

    def resign_affected_zones(self, zone):
        if self.publish_all_ksks_in_view in (None, zone.view):
            return

        logger.info('Re-signing zones affected by changes to %s...' % zone)
        for cls, view in self.named_conf_obj.zones[zone.origin]:
            zone_type = self.named_conf_obj.zone_type(zone.origin,cls,view)
            if zone_type is None or zone_type.lower() != 'master':
                continue

            if view != self.publish_all_ksks_in_view:
                continue

            try:
                zone_log = self.get_zone_log(zone.origin, view=view, write=True, cache=False)
            except ZoneNotManaged:
                continue
            except LogError, e:
                logger.error('Unable to resign %s: %s' % (zone_str(zone.origin, 'IN', view), e))
                continue

            other_zone = self.get_zone(zone.origin, view=view, write=True, cache=False)
            self._resign(other_zone, zone_log)

    def bootstrap(self, origin, view=None, **kwargs):
        if view is None:
            view = self.default_view
        # note that in all the other methods, the Zone is instantiated before
        # the ZoneLog.  In bootstrap, we are calling with create=True, so we
        # want to make sure the zone exists and is suitable before creating
        # the log directory and file
        zone = self.get_zone(origin, view=view, write=True, create=True)
        zone_log = self.get_zone_log(origin, view=view, write=True, create=True)
        self._bootstrap(zone, zone_log, **kwargs)

    bootstrap.modifies_zone = True

    def _bootstrap(self, zone, zone_log,
            algorithm='RSASHA1', nsec3=False, nsec3_iter=2, nsec3_optout=False,
            prand=False, ksk_file=None, ksk_bits=2048, 
            zsk_pub_file=None, zsk_active_file=None, zsk_bits=2048, verify_sign=True):
        '''Sign a previously unsigned zone.  Optionally generate published/active zsks
        and/or ksk with specified parameters.'''

        if not sys.stdout.isatty():
            raise InteractionNeeded()

        pre_signed = zone.is_signed

        # check existence/readability of key files supplied
        for path in (ksk_file, zsk_active_file, zsk_pub_file):
            if path is None:
                continue
            path = strip_key_suffix(path)
            for ext in DNSKEY_SUFFIXES:
                self.file_readable(path+ext, 'Key file')

        zone_state = zone_log.current_state()
        # since we are bootstrapping, there shouldn't be any existing states
        if zone_state is not None:
            raise StateTransitionError('Bootstrapping %s from current state "%s" not allowed.' % (zone, zone_state.name))

        logger.info('Bootstrapping %s...' % zone)

        # if the zone was previously signed, do some extra checks
        if pre_signed:
            console_logger.info('  %s is previously signed' % zone.origin)

            # ensure that the zone has exactly one active ZSK and no more than one published ZSK
            if len(zone.active_zsks) != 1:
                raise StateTransitionError('Exactly one active ZSK is required for bootstrapping previously-signed zone %s in %s.' % (zone.origin, self.zone_file))
            if len(zone.published_zsks) > 1:
                raise StateTransitionError('No more than one published ZSK is allowed for bootstrapping previously-signed zone %s in %s.' % (zone.origin, self.zone_file))
            # ensure that the zone has exactly one active KSK and no published KSKs
            if len(zone.active_ksks) != 1:
                raise StateTransitionError('Exactly one active KSK is required for bootstrapping previously-signed zone %s in %s.' % (zone.origin, self.zone_file))
            if len(zone.published_ksks):
                raise StateTransitionError('No published KSKs are allowed for bootstrapping previously-signed zone %s in %s.' % (zone.origin, self.zone_file))

            # if the active ZSK is specified, then it should match
            # the one detected in the zone file
            if zsk_active_file is not None:
                key_obj = DNSSECKey.from_file(zsk_active_file)
                if key_obj != zone.active_zsks[0]:
                    raise ConfigurationError('Active ZSK for %s specified does not match active ZSK detected in %s: %s <> %s' % (zone.origin, zone.zone_file, key_obj.file, zone.active_zsks[0].file))
                zone.active_zsks[0] = key_obj
            elif zone.active_zsks[0].file is None:
                raise ConfigurationError('Please specify file location for active ZSK %s' % (zone.active_zsks[0]))
            else:
                zsk_active_file = zone.active_zsks[0].file

            # if the published ZSK is specified, and there is one
            # in the zone file, then they should match
            if zone.published_zsks:
                if zsk_pub_file is not None:
                    key_obj = DNSSECKey.from_file(zsk_pub_file)
                    if key_obj != zone.published_zsks[0]:
                        raise ConfigurationError('Published ZSK for %s specified does not match published ZSK detected in %s: %s <> %s' % (zone.origin, zone.zone_file, key_obj.file, zone.published_zsks[0].file))
                    zone.published_zsks[0] = key_obj
                else:
                    zsk_pub_file = zone.published_zsks[0].file

            # if the KSK is specified, then it should match
            # the one detected in the zone file
            if ksk_file is not None:
                key_obj = DNSSECKey.from_file(ksk_file)
                if key_obj != zone.active_ksks[0]:
                    raise ConfigurationError('Active KSK for %s specified does not match active KSK detected in %s: %s <> %s' % (zone.origin, self.zone_file, key_obj.file, zone.active_ksks[0].file))
                zone.active_ksks[0] = key_obj
            elif zone.active_ksks[0].file is None:
                raise ConfigurationError('Please specify file location for active KSK %s' % (zone.active_ksks[0]))
            else:
                ksk_file = zone.active_ksks[0].file

        # not previously signed
        else:
            console_logger.info('  %s is unsigned' % zone.origin)

        if nsec3 and algorithm.upper() in ('RSASHA1', 'DSA'):
            algorithm = 'NSEC3'+algorithm.upper()

        if pre_signed:
            # perform a check about going between NSEC3/non-NSEC3
            if nsec3 != zone.nsec3:
                raise ConfigurationError('NSEC3 use must match that of the previously signed zone when bootstrapping.')

        else:
            # if the signed file already exists, raise an error
            if os.path.exists(zone.signed_zone_file()):
                raise ConfigurationError('Signed zone file %s already exists.  Please remove it manually if you really wish to overwrite.' % (zone.signed_zone_file()))

        generated_keys = []
        pre_sign_time = time.localtime()
        try:
            # generate the KSK, if it doesn't
            # already exist
            if ksk_file is None:
                console_logger.info('  Generating KSK...')
                flush_handler('console')
                ksk_file = gen_ksk(zone.origin, algorithm, ksk_bits, self.randomdev)
                ksk_obj = DNSSECKey.from_file(ksk_file)
                generated_keys.append(ksk_obj)
                console_logger.info('  New KSK: %s' % ksk_obj.filename())
            else:
                ksk_obj = DNSSECKey.from_file(ksk_file)

            # generate the active ZSK, if it doesn't
            # already exist
            if zsk_active_file is None:
                console_logger.info('  Generating active ZSK...')
                flush_handler('console')
                zsk_active_file = gen_zsk(zone.origin, algorithm, zsk_bits, self.randomdev)
                zsk_active_obj = DNSSECKey.from_file(zsk_active_file)
                generated_keys.append(zsk_active_obj)
                console_logger.info('  New active ZSK: %s' % zsk_active_obj.filename())
            else:
                zsk_active_obj = DNSSECKey.from_file(zsk_active_file)

            # generate the published ZSK, if it doesn't
            # already exist
            if zsk_pub_file is None:
                console_logger.info('  Generating published ZSK...')
                flush_handler('console')
                zsk_pub_file = gen_zsk(zone.origin, algorithm, zsk_bits, self.randomdev)
                zsk_pub_obj = DNSSECKey.from_file(zsk_pub_file)
                generated_keys.append(zsk_pub_obj)
                console_logger.info('  New published ZSK: %s' % zsk_pub_obj.filename())
            else:
                zsk_pub_obj = DNSSECKey.from_file(zsk_pub_file)

            # freeze the zone
            zone.freeze()

            try:
                # import the keys
                zone.import_active_ksk(ksk_obj, move=(ksk_obj in generated_keys))
                zone.import_active_zsk(zsk_active_obj, move=(zsk_active_obj in generated_keys), gid=self.named_gid)
                zone.import_published_zsk(zsk_pub_obj, move=(zsk_pub_obj in generated_keys))

                # identify additional KSKs that should be published
                included_ksks = self.published_ksks_from_other_views(zone)

                # sign the zone
                console_logger.info('  Signing %s' % zone)
                flush_handler('console')
                zone.sign_zone(included_ksks=included_ksks, nsec3=nsec3, nsec3_iter=nsec3_iter, nsec3_optout=nsec3_optout, verify_sign=verify_sign,
                        randomdev=self.randomdev, prand=prand, gen_ds_rrs=self.gen_ds_rrs, uid=self.named_uid, gid=self.named_gid)

                # since the zone is signed, the generated_keys are now in use
                generated_keys = []

                # send user message here about modifying named.conf and
                if not pre_signed:
                    while True:
                        sys.stdout.write('''
******************************************************
Please modify the `file' statement for %s in
%s to use "%s".

Press [Enter] when finished to reload the reconfiguration
and reload the signed zone.
******************************************************
''' % (zone, self.named_conf, self.chroot_relative(zone.zone_file)))
                        line = sys.stdin.readline()
                        line = line.rstrip()
                        # values extracted from named.conf
                        try:
                            self.named_conf_obj = NamedConf(self.named_conf, self.chroot)
                        except CommandError, e:
                            sys.stderr.write('Error re-reading %s: %s\n' % (self.named_conf, e))
                            continue
                        new_zone_file = self.named_conf_obj.zone_file(zone.origin, view=zone.view)
                        if new_zone_file == zone.zone_file:
                            # reload the named configuration, which includes the new zone file
                            # (this will also reload the zone)
                            rndc_reload_conf()
                            break

                    if zone.is_dynamic:
                        # if the zone is dynamic, move the unsigned file out of the way
                        backup_zone_file = zone.unsigned_zone_file.rstrip('.')+'.'+time.strftime('%Y%m%d', time.localtime())
                        logger.info('Moving unsigned zone file %s to %s' % (zone.unsigned_zone_file, backup_zone_file))
                        console_logger.debug('mv %s %s' % (zone.unsigned_zone_file,backup_zone_file))
                        shutil.move(zone.unsigned_zone_file,backup_zone_file)

                # reload the zone
                else:
                    zone.reload()

                wait_secs = self.propagation_time + zone.max_key_ttl
                expire_secs = time.mktime(time.localtime()) + wait_secs
                zone_state = zone.to_state('signed', time.localtime(expire_secs))

                zone_log.write_state(zone_state)

                ds_str, dnskey_str = self.get_zone_ds(zone.origin, zone)
                if self.dlv_domain is not None:
                    parent_zone = '%s or %s (for DLV service)' % (parent(zone.origin).rstrip('.'), canonicalize_name(self.dlv_domain).rstrip('.'))
                    rr_type = 'DS or DLV'
                else:
                    parent_zone = '%s' % (parent(zone.origin).rstrip('.'))
                    rr_type = 'DS'
                kwargs = { 'parent_zone': parent_zone, 'rr_type': rr_type, 'zone': zone.origin.rstrip('.'), 'dnskey': dnskey_str }
                sys.stdout.write('''
******************************************************
%(dnskey)s

If you wish to establish a chain of trust,
please present the %(parent_zone)s zone with the DNSKEY RRset shown above,
so the %(rr_type)s RRset for %(zone)s may be properly updated.
******************************************************
''' % kwargs)

                # resign any zones in views which publish these KSKs
                self.resign_affected_zones(zone)

            finally:
                # thaw the zone
                zone.thaw()

        except:
            try:
                if not os.path.exists(zone.zone_file) or \
                        os.path.getmtime(zone.zone_file) < pre_sign_time:
                    for key in generated_keys:
                        key.remove_files()
            except:
                logger.exception('Error cleaning up keys')
            raise

    def showds(self, origin):
        """Display DS RRs for a zone"""

        ds_str, dnskey_str = self.get_zone_ds(origin)
        sys.stdout.write('%s\n%s' % (ds_str, dnskey_str))

    def showall(self, origin, view=None):
        """Display information about a zone: name, serial, key information, state, expiration, etc."""

        if view is None:
            view = self.default_view

        managed = True
        try:
            zone_log = self.get_zone_log(origin, view=view)
            zone_state = zone_log.current_state()
        except ZoneNotManaged:
            zone_log = None
            zone_state = None
            managed = False
        except LogError, e:
            zone_log = None
            zone_state = None
            logger.error('Unreadable log file for %s: %s' % (zone_str(origin, 'IN', view), e))

        zone = self.get_zone(origin, view=view)
        sys.stdout.write('*****************\n')
        sys.stdout.write('Zone %s\n' % zone)
        sys.stdout.write('*****************\n')

        sys.stdout.write('Serial: %d\n' % zone.serial)
        if zone.is_dynamic:
            sys.stdout.write('  (Serial may be inaccurate since zone is dynamic)\n')
        sys.stdout.write('Zone file: %s\n' % zone.zone_file)
        sys.stdout.write('Dynamic: %s\n' % zone.is_dynamic)
        sys.stdout.write('Signed: %s (%s)\n' % (zone.is_signed, managed and 'managed' or 'unmanaged'))
        if managed:
            sys.stdout.write('Zone directory: %s\n' % zone.meta_directory)
        if zone.is_signed:
            if zone.is_dynamic:
                sys.stdout.write('Key directory: %s\n' % (zone.key_directory or '[unknown]'))
            else:
                sys.stdout.write('Unsigned zone file: %s\n' % (zone.unsigned_zone_file or '[unknown]'))
                sys.stdout.write('Unsigned zone serial: %s\n' % (zone.unsigned_serial or '[unknown]'))
        sys.stdout.write('\n') 

        if zone_state is not None:
            sys.stdout.write('State information:\n')
            sys.stdout.write('  State file: %s\n' % zone_log.file)
            sys.stdout.write('  Current state: %s (since %s, serial %d)\n' % \
                (zone_state.name, time.strftime('%x %X', zone_state.start), zone_state.serial))
            if time.localtime() < zone_state.expire:
                sys.stdout.write('                 immutable until: %s\n' % \
                        (time.strftime('%x %X', zone_state.expire)))
            try:
                zone_state.check_keys(zone)
                sys.stdout.write('  DNSSEC keys: consistent\n')
            except InconsistentKeys, e:
                sys.stdout.write('  DNSSEC keys: %s\n' % e)
            sys.stdout.write('\n') 
        else:
            sys.stdout.write('State unknown\n\n')

        def _print_key_info(state, key):
            if key.key is not None:
                bits = '%d' % key.key_len()
            else:
                bits = '[unknown]' % key.key_len()

            sys.stdout.write('  %12s %s %12s %5s\n' % ('(%s)' % state, key.filename(), DNSKEY_ALGORITHMS.get(key.algorithm, '[unknown]'), bits))

            if zone.meta_directory is None:
                age_str = '[key directory not specified!]'
            elif key.file is None:
                age_str = '[file not found!]'
            else:
                # calculate age, and remove microseconds
                age_str = '%s (%s hours ago)' % \
                        (time.strftime('%x %X', key.file_mtime), re.sub(r'.\d*$', '', str(datetime.datetime.now() - datetime.datetime(*key.file_mtime[0:6]))))
            sys.stdout.write('               Created: %s\n' % age_str)

            if zone_log is not None:
                pub_date, active_date = zone_log.key_info(key.filename())
                if pub_date is not None:
                    # calculate age, and remove microseconds
                    age_str = '%s (%s hours ago)' % \
                            (time.strftime('%x %X', pub_date), re.sub(r'.\d*$', '', str(datetime.datetime.now() - datetime.datetime(*pub_date[0:6]))))
                    sys.stdout.write('             Published: %s\n' % age_str)

                if active_date is not None:
                    # calculate age, and remove microseconds
                    age_str = '%s (%s hours ago)' % \
                            (time.strftime('%x %X', active_date), re.sub(r'.\d*$', '', str(datetime.datetime.now() - datetime.datetime(*active_date[0:6]))))
                    sys.stdout.write('                Active: %s\n' % age_str)

        # print key information
        sys.stdout.write('Zone-signing Keys (ZSKs):\n')
        for key in zone.active_zsks:
            _print_key_info('active', key)
        for key in zone.published_zsks:
            _print_key_info('published', key)
        for key in zone.unpublished_zsks:
            _print_key_info('unpublished', key)
        sys.stdout.write('\n') 

        sys.stdout.write('Key-signing Keys (KSKs):\n')
        for key in zone.active_ksks:
            _print_key_info('active', key)
        for key in zone.published_ksks:
            _print_key_info('published', key)
        for key in zone.unpublished_ksks:
            _print_key_info('unpublished', key)
        sys.stdout.write('\n') 

        # print max TTL
        sys.stdout.write('Max TTL:\n')
        sys.stdout.write('  %d (%s %s)\n\n' % (zone.max_ttl, zone.max_ttl_rrname, zone.max_ttl_rrtype))

        if zone.active_zsks:
            # calculate expiration time (and remove microseconds)
            d = re.sub(r'.\d*$', '', str(datetime.datetime(*zone.min_expire_dt[0:6]) - datetime.datetime.now()))

            # print next record expiration
            sys.stdout.write('Next record expires:\n')
            sys.stdout.write('   %s (%s hours) (%s %s)\n\n' % (time.strftime('%x %X', zone.min_expire_dt), d, zone.min_expire_rrname, zone.min_expire_rrtype))

            # print NSEC3 information
            sys.stdout.write('NSEC3:\n')
            if zone.nsec3:
                if zone.nsec3_salt_varies:
                    salt_val = 'various'
                else:
                    salt_val = '0x%06x' % zone.nsec3_salt
                if zone.nsec3_iter_varies:
                    iter_val = 'various'
                else:
                    iter_val = '%6d' % zone.nsec3_iter
                sys.stdout.write('  Salt:         %s\n' % salt_val)
                sys.stdout.write('  Iterations:   %s\n' % iter_val)
                sys.stdout.write('  Opt-out bit:  %8s\n' % zone.nsec3_optout)
            else:
                sys.stdout.write('  not used\n')
            sys.stdout.write('\n')

        # if there are any warnings, print them here
        for w in zone.warnings:
            logger.warn('  %s' % w)

    def showkeys(self, origin, view=None):
        """Display key information for a zone."""

        if view is None:
            view = self.default_view

        try:
            zone_log = self.get_zone_log(origin, view=view)
            zone_state = zone_log.current_state()
        except ZoneNotManaged:
            zone_log = None
            zone_state = None
        except LogError, e:
            zone_log = None
            zone_state = None
            logger.error('Unreadable log file for %s: %s' % (zone_str(origin, 'IN', view), e))

        zone = self.get_zone(origin, view=view)

        if not zone.is_signed:
            sys.stderr.write('Zone %s is not signed.\n' % zone)
            return

        sys.stdout.write('Zone %s\n' % zone)

        def _print_key_info(key_type, key, active):
            if key.key is not None:
                bits = '%d' % key.key_len()
            else:
                bits = '[unknown]' % key.key_len()

            sys.stdout.write(' %s%s %s %12s %5s\n' % \
                    (active and '*' or ' ', key_type, key.filename(), DNSKEY_ALGORITHMS.get(key.algorithm, '[unknown]'), bits))

            if zone_log is not None:
                pub_date, active_date = zone_log.key_info(key.filename())
                sys.stdout.write('      ')
                if pub_date is not None:
                    sys.stdout.write('Published since: %s' % time.strftime('%x', pub_date))
                # unpublished
                elif active_date is None:
                    sys.stdout.write('Published since: [unknown]')

                if active:
                    if active_date is not None:
                        sys.stdout.write(';  Active since: %s' % time.strftime('%x', active_date))
                    # unpublished
                    elif pub_date is None:
                        sys.stdout.write(';  Active since: [unknown]')
                sys.stdout.write('\n')

        active_exists = False
        # print key information
        for key in zone.active_zsks:
            _print_key_info('ZSK', key, True)
            active_exists = True
        for key in zone.published_zsks:
            _print_key_info('ZSK', key, False)
        for key in zone.unpublished_zsks:
            active_exists = True
            _print_key_info('ZSK', key, True)

        for key in zone.active_ksks:
            _print_key_info('KSK', key, True)
            active_exists = True
        for key in zone.published_ksks:
            _print_key_info('KSK', key, False)
        for key in zone.unpublished_ksks:
            active_exists = True
            _print_key_info('KSK', key, True)

        if active_exists:
            sys.stdout.write(' * - active key\n')

        if zone_state is not None:
            try:
                zone_state.check_keys(zone)
                sys.stdout.write('DNSSEC keys: consistent\n')
            except InconsistentKeys, e:
                sys.stdout.write('DNSSEC keys: %s\n' % e)

    def resign(self, origin, view=None, **kwargs):
        if view is None:
            view = self.default_view

        zone_log = self.get_zone_log(origin, view=view, write=True)
        zone = self.get_zone(origin, view=view, write=True)
        self._resign(zone, zone_log, **kwargs)

    resign.modifies_zone = True

    def _resign(self, zone, zone_log, nsec3_iter=None, nsec3_optout=None, interval=None, prand=False, verify_sign=True, block=True):
        """Resign a previously-signed zone with the same keys and options it
        was previously signed with."""

        zone_state = zone_log.current_state()
        # make sure we have a valid state
        if zone_state is None:
            raise ConfigurationError('Current state of %s unknown.' % zone)
        next_state = zone_state.name

        # identify additional KSKs that should be published
        included_ksks = self.published_ksks_from_other_views(zone)

        # make sure the state transition is valid
        zone_state.advance(zone, next_state, None, serial_must_be_same=False)

        # for static zones, if there is a new serial in the unsigned version,
        # check that it is of sufficient size
        if not zone.is_dynamic and zone.unsigned_serial != zone_state.unsigned_serial:
            if zone.unsigned_serial <= zone.serial:
                raise ConfigurationError('Serial in unsigned version of zone (%d) must be greater than serial in signed version of zone (%d)' % (zone.unsigned_serial, zone.serial))
            new_serial = zone.unsigned_serial
        else:
            new_serial = 0

        if interval is None:
            interval = self.sig_renewal_window
        elif not isinstance(interval, datetime.timedelta):
            interval = datetime.timedelta(seconds=interval)

        # ensure that the zone was previously signed
        if not zone.is_signed:
            raise ConfigurationError('%s not previously signed with any keys!' % zone_file)

        if block:
            # wait for current state to expire, if in blocking mode
            logger.info('Re-signing %s...' % zone)
            flush_handler('console')
            zone_state.advance(zone, next_state, block, serial_must_be_same=False)
        else:
            zone_state.advance(zone, next_state, block, serial_must_be_same=False)
            logger.info('Re-signing %s...' % zone)
            flush_handler('console')

        # disable maintenance, and freeze the zone
        self._disable_maintenance_alarm()
        zone.freeze()

        try:
            console_logger.info('  Signing %s: %s' % (zone.origin, zone.zone_file))
            flush_handler('console')
            zone.sign_zone(new_serial=new_serial, included_ksks=included_ksks, nsec3_iter=nsec3_iter, nsec3_optout=nsec3_optout, verify_sign=verify_sign, interval=interval,
                    randomdev=self.randomdev, prand=prand, gen_ds_rrs=self.gen_ds_rrs, uid=self.named_uid, gid=self.named_gid)

            # reload the zone
            zone.reload()

            # write the new state
            zone_state = zone.to_state(next_state, zone_state.expire)
            zone_log.write_state(zone_state)

        finally:
            # thaw the zone
            zone.thaw()
            self._enable_maintenance_alarm()

    def _update_ds(self, zone):

        dlv_domains = [None]
        if self.dlv_domain is not None:
            dlv_domains.append(self.dlv_domain)

        wait_secs = 0
        for dlv_domain in dlv_domains:
            
            if dlv_domain is None:
                rr_type = 'DS'
            else:
                rr_type = 'DLV'

            if dlv_domain is not None:
                parent_zone = canonicalize_name(dlv_domain)
                qname = zone.origin + parent_zone
            else:
                parent_zone = parent(zone.origin)
                qname = zone.origin

            try:
                prev_ds_ttl = zone.ds_ttl(dlv_domain)
                if prev_ds_ttl is None:
                    prev_ds_ttl = -1
            except ZoneError:
                prev_ds_ttl = None

            kwargs = { 'zone': zone.origin.rstrip('.'), 'rr_type': rr_type,
                    'parent': parent_zone.rstrip('.'), 'ttl': prev_ds_ttl,
                    'qname': qname.rstrip('.') }

            if prev_ds_ttl is None or self.ksk_update_style != 'auto':
                if not sys.stdout.isatty():
                    raise InteractionNeeded()

                # if we were unable to detect the TTL of the DS RR
                if prev_ds_ttl is None:
                    msg = '''
    Unable to successfully detect the TTL for %(qname)s/%(rr_type)s.  If
    %(qname)s/%(rr_type)s does not exist in the %(parent)s zone, then please enter "none".  Otherwise,
    please enter the TTL of the current %(qname)s/%(rr_type)s RRset.  (To find the
    TTL, issue a direct query for '%(qname)s %(rr_type)s' to a server authoritative for %(parent)s): ''' % kwargs

                # a TTL < 0 means that the DS record wasn't signed or did not exist
                elif prev_ds_ttl < 0:
                    msg = '''
    Either %(qname)s/%(rr_type)s does not exist in the %(parent)s zone
    or %(parent)s is not signed.  In either case, there is no need to wait for the expiry of a %(rr_type)s RR.
    Please press [Enter] to continue or enter a new wait value: ''' % kwargs

                # we detected a TTL >= 0, but we are not configured to do things automatically
                else:
                    msg = '''
    A TTL of %(ttl)d was detected for %(qname)s/%(rr_type)s.
    Please press [Enter] to accept this value or enter a new value.  To find the
    TTL, issue a direct query for '%(qname)s %(rr_type)s' to a server authoritative for %(parent)s [%(ttl)d]: ''' % kwargs

                sys.stdout.write('''\n******************************************************''')
                while True:
                    sys.stdout.write(msg)
                    line = sys.stdin.readline().strip()
                    if line == 'none' and prev_ds_ttl is None:
                        break
                    elif line == '' and prev_ds_ttl is not None:
                        break
                    try:
                        val = int(line)
                        if val >= 0:
                            prev_ds_ttl = val
                            break
                    except ValueError:
                        pass

            if prev_ds_ttl is not None and prev_ds_ttl >= 0:
                if not sys.stdout.isatty():
                    raise InteractionNeeded()
                sys.stdout.write('''\n******************************************************''')
                while True:
                    sys.stdout.write('''
    When you are ready to update the %(qname)s/%(rr_type)s in %(parent)s,
    type "ok", then press [Enter], and you will be presented with
    the appropriate records: ''' % kwargs)
                    line = sys.stdin.readline()
                    line = line.rstrip()
                    if line == 'ok':
                        break

                ds_str, dnskey_str = self.get_zone_ds(zone.origin, zone)
                kwargs['dnskey'] = dnskey_str
                sys.stdout.write('''
    %(dnskey)s

    Please present the %(parent)s zone with the DNSKEY RRset
    shown above, as appropriate, so the %(rr_type)s RRset may be
    properly updated and a chain of trust with the %(parent)s zone may be
    established or maintained.
    ''' % kwargs)

                while True:
                    sys.stdout.write('''\nWhen the new %(qname)s/%(rr_type)s RRset has been successfully published in
the %(parent)s zone, type "ok" then [Enter].  Note that the process of submitting the
new DNSKEYs to the %(parent)s zone, does not mean the new %(rr_type)s RRs are yet
present.  Please verify their existence with a query for '%(qname)s %(rr_type)s'
before continuing: ''' % kwargs)
                    line = sys.stdin.readline()
                    line = line.rstrip()
                    if line == 'ok':
                        break
                wait_secs = max(self.propagation_time + prev_ds_ttl, wait_secs)

        sys.stdout.write('''******************************************************\n\n''')

        return wait_secs

    def rollalg(self, origin, view=None, **kwargs):
        if view is None:
            view = self.default_view

        zone_log = self.get_zone_log(origin, view=view, write=True)
        zone = self.get_zone(origin, view=view, write=True, no_freeze=True)
        self._rollalg(zone, zone_log, **kwargs)

    rollalg.modifies_zone = True

    def _rollalg(self, zone, zone_log, algorithm='RSASHA1', zsk_bits=None, ksk_bits=None,
            nsec3=False, nsec3_iter=2, nsec3_optout=False,
            prand=False, verify_sign=True):
        """Follow procedure for rolling algorithm following RFC 4641."""

        # check existence/readability of key files supplied
        zone_state = zone_log.current_state()
        # make sure we have a valid state
        if zone_state is None:
            raise ConfigurationError('Current state of %s unknown.' % zone)

        # perform a check about going between NSEC3/non-NSEC3
        if zone.nsec3 and not nsec3:
            raise ConfigurationError('Transitioning from NSEC3 to non-NSEC3 is not supported.')

        if nsec3 and algorithm.upper() in ('RSASHA1', 'DSA'):
            algorithm = 'NSEC3'+algorithm.upper()

        valid = False
        if zone_state.name == 'signed':
            zone_state = self._rollalg_new_rrsigs(zone, zone_state, zone_log, algorithm, zsk_bits=zsk_bits, ksk_bits=ksk_bits,
                    prand=prand, verify_sign=verify_sign)
            valid = True

        if zone_state.name == 'alg-roll-wait-ttl1':
            zone_state = self._rollalg_new_dnskey(zone, zone_state, zone_log, prand=prand, verify_sign=verify_sign)
            valid = True

        if zone_state.name == 'alg-roll-wait-dschange':
            zone_state = self._rollalg_ds_change(zone, zone_state, zone_log)
            valid = True

        if zone_state.name == 'alg-roll-wait-dsttl':
            zone_state = self._rollalg_remove_dnskey(zone, zone_state, zone_log, nsec3, nsec3_iter, nsec3_optout, prand=prand, verify_sign=verify_sign)
            valid = True

        if zone_state.name == 'alg-roll-wait-ttl2':
            zone_state = self._rollalg_remove_rrsigs(zone, zone_state, zone_log, algorithm, zsk_bits=zsk_bits, prand=prand, verify_sign=verify_sign)
            valid = True

        if not valid:
            raise StateTransitionError('Zone %s in unsuitable state "%s" for algorithm rollover.' % (zone, zone_state.name))

    def _rollalg_new_rrsigs(self, zone, zone_state, zone_log, algorithm, zsk_bits=None, ksk_bits=None,
            prand=False, verify_sign=True):
        """Follow procedure for rolling algorithm following RFC 4641."""

        # identify additional KSKs that should be published
        included_ksks = self.published_ksks_from_other_views(zone)

        next_state = 'alg-roll-wait-ttl1'
        # make sure the state transition is valid
        zone_state.advance(zone, next_state, None)

        # for simplicity ensure that the zone has no unpublished keys
        if len(zone.unpublished_zsks) > 0:
            raise StateTransitionError('There must no unpublished ZSKs for %s when initiating an algorithm rollover.' % zone.origin)
        if len(zone.unpublished_ksks) > 0:
            raise StateTransitionError('There must no unpublished KSKs for %s when initiating an algorithm rollover.' % zone.origin)

        # wait for current state to expire
        logger.info('Entering new RRSIGs 1 phase of algorithm rollover for %s...' % zone)
        flush_handler('console')

        zone_state.advance(zone, next_state, True)

        if zsk_bits is None:
            zsk_bits = zone.active_zsks[0].key_len()
        if ksk_bits is None:
            ksk_bits = zone.active_ksks[0].key_len()

        generated_keys = []
        pre_sign_time = time.localtime()
        try:
            # generate the unpublished ZSK
            console_logger.info('  Generating unpublished ZSK...')
            flush_handler('console')
            zsk_unpub_file = gen_zsk(zone.origin, algorithm, zsk_bits, self.randomdev)
            zsk_unpub_obj = DNSSECKey.from_file(zsk_unpub_file)
            generated_keys.append(zsk_unpub_obj)
            console_logger.info('  New unpublished ZSK: %s' % zsk_unpub_obj.filename())

            # generate the unpublished KSK
            console_logger.info('  Generating unpublished KSK...')
            flush_handler('console')
            ksk_unpub_file = gen_ksk(zone.origin, algorithm, ksk_bits, self.randomdev)
            ksk_unpub_obj = DNSSECKey.from_file(ksk_unpub_file)
            generated_keys.append(ksk_unpub_obj)
            console_logger.info('  New unpublished KSK: %s' % ksk_unpub_obj.filename())

            # freeze the zone
            zone.freeze()

            # refresh the frozen zone, and make sure we still have a valid state
            zone.refresh_zone_info(included_ksks)
            zone_state.advance(zone, next_state, True)

            # get the max_ttl from the previous version of the zone
            max_ttl = zone.max_ttl

            # disassociate any published keys (to be archived later)
            old_published_keys = zone.published_zsks[:] + zone.published_ksks[:]
            zone.published_zsks = []
            zone.published_ksks = []

            # import unpublished keys
            zone.import_unpublished_ksk(ksk_unpub_obj, move=(ksk_unpub_obj in generated_keys))
            zone.import_unpublished_zsk(zsk_unpub_obj, move=(zsk_unpub_obj in generated_keys), gid=self.named_gid)

            # sign the zone with the previously-published ZSK
            console_logger.info('  Signing %s: %s' % (zone.origin, zone.zone_file))
            flush_handler('console')
            zone.sign_zone(included_ksks=included_ksks, verify_sign=verify_sign, randomdev=self.randomdev, prand=prand,
                    gen_ds_rrs=self.gen_ds_rrs, uid=self.named_uid, gid=self.named_gid)

            # reload the zone
            zone.reload()

            wait_secs = self.propagation_time + max_ttl
            expire_secs = time.mktime(time.localtime()) + wait_secs
            expire_time = time.localtime(expire_secs)
            zone_state = zone.to_state(next_state, expire_time)
            zone_log.write_state(zone_state)

            # archive previously published keys
            for key in old_published_keys:
                logger.info('  Archiving key previously published in %s: %s' % (zone, key.filename()))
                self.archive_key(key, zone)

            return zone_state

        except:
            try:
                if not os.path.exists(zone.zone_file) or \
                        os.path.getmtime(zone.zone_file) < pre_sign_time:
                    for key in generated_keys:
                        key.remove_files()
            except:
                logger.exception('Error cleaning up keys')
            raise

    def _rollalg_new_dnskey(self, zone, zone_state, zone_log, prand=False, verify_sign=True):
        """Follow procedure for rolling algorithm following RFC 4641."""

        # identify additional KSKs that should be published
        included_ksks = self.published_ksks_from_other_views(zone)

        next_state = 'alg-roll-wait-dschange'
        # make sure the state transition is valid
        zone_state.advance(zone, next_state, None)

        # for simplicity ensure that the zone has exactly one of unpublished keys
        if len(zone.active_zsks) != 1:
            raise StateTransitionError('There must exactly one active ZSK for %s when resuming an algorithm rollover.' % zone.origin)
        if len(zone.active_ksks) != 1:
            raise StateTransitionError('There must exactly one active KSK for %s when resuming an algorithm rollover.' % zone.origin)
        if len(zone.unpublished_zsks) != 1:
            raise StateTransitionError('There must exactly one unpublished ZSK for %s when resuming an algorithm rollover.' % zone.origin)
        if len(zone.unpublished_ksks) != 1:
            raise StateTransitionError('There must exactly one unpublished KSK for %s when resuming an algorithm rollover.' % zone.origin)

        # wait for current state to expire
        logger.info('Entering new DNSKEY phase of algorithm rollover for %s...' % zone)
        flush_handler('console')
        zone_state.advance(zone, next_state, True)

        # freeze the zone
        zone.freeze(frozen_ok=True)
        
        # refresh the frozen zone, and make sure we still have a valid state
        zone.refresh_zone_info(included_ksks)
        zone_state.advance(zone, next_state, True)

        # swap unpublished/active keys
        old_unpub_zsk = zone.unpublished_zsks.pop()
        old_unpub_ksk = zone.unpublished_ksks.pop()
        zone.import_active_zsk(old_unpub_zsk, move=True, gid=self.named_gid)
        zone.import_active_ksk(old_unpub_ksk, move=True)

        # sign the zone with the previously-published ZSK
        console_logger.info('  Signing %s: %s' % (zone.origin, zone.zone_file))
        flush_handler('console')
        zone.sign_zone(included_ksks=included_ksks, verify_sign=verify_sign, randomdev=self.randomdev, prand=prand,
                gen_ds_rrs=self.gen_ds_rrs, uid=self.named_uid, gid=self.named_gid)

        # reload the zone
        zone.reload()

        # thaw the zone
        zone.thaw()

        zone_state = zone.to_state(next_state, time.localtime())

        zone_log.write_state(zone_state)

        return zone_state

    def _rollalg_ds_change(self, zone, zone_state, zone_log):

        # resign any zones in views which publish these KSKs
        self.resign_affected_zones(zone)

        logger.info('Entering DS change phase of algorithm DS rollover for %s...' % zone)
        flush_handler('console')

        next_state = 'alg-roll-wait-dsttl'
        # make sure the state transition is valid
        zone_state.advance(zone, next_state, True)

        wait_secs = self._update_ds(zone)

        expire_secs = time.mktime(time.localtime()) + wait_secs
        expire_time = time.localtime(expire_secs)
        zone_state = zone.to_state(next_state, expire_time)
        zone_log.write_state(zone_state)

        return zone_state

    def _rollalg_remove_dnskey(self, zone, zone_state, zone_log, nsec3, nsec3_iter, nsec3_optout, prand=False, verify_sign=True):
        """Follow procedure for rolling algorithm following RFC 4641."""

        # identify additional KSKs that should be published
        included_ksks = self.published_ksks_from_other_views(zone)

        next_state = 'alg-roll-wait-ttl2'
        # make sure the state transition is valid
        zone_state.advance(zone, next_state, None)

        # for simplicity ensure that the zone has exactly one of unpublished keys
        if len(zone.active_zsks) != 2:
            raise StateTransitionError('There must be exactly two active ZSKs for %s when resuming an algorithm rollover.' % zone.origin)
        if len(zone.active_ksks) != 2:
            raise StateTransitionError('There must be exactly two active KSKs for %s when resuming an algorithm rollover.' % zone.origin)

        # find out which key was published first, and that one will be removed
        pub0,act0 = zone_log.key_info(zone.active_ksks[0].filename())
        pub1,act1 = zone_log.key_info(zone.active_ksks[1].filename())
        if pub0 < pub1:
            old_ksk = zone.active_ksks[0]
            ksk_obj = zone.active_ksks[1]
        else:
            old_ksk = zone.active_ksks[1]
            ksk_obj = zone.active_ksks[0]
        pub0,act0 = zone_log.key_info(zone.active_zsks[0].filename())
        pub1,act1 = zone_log.key_info(zone.active_zsks[1].filename())
        if pub0 < pub1:
            old_zsk = zone.active_zsks[0]
        else:
            old_zsk = zone.active_zsks[1]

        # wait for current state to expire
        logger.info('Entering remove DNSKEY phase of algorithm rollover for %s...' % zone)
        flush_handler('console')
        zone_state.advance(zone, next_state, True)

        # query for new DS key to be sure it exists
        try:
            ds_ttl = zone.ds_ttl()
            if ds_ttl is not None:
                ds_exists, rrsig_exists = zone.ds_exists(ksk_obj)
                if not ds_exists:
                    # revert to wait DS change state, and raise an error
                    zone_state = zone.to_state('alg-roll-wait-dschange', time.localtime())
                    zone_log.write_state(zone_state)
                    raise ConfigurationError('DS RR for new KSK %s does not exist (was it properly added to the %s zone?)\nPlease try the algorithm rollover again.' %
                            (ksk_obj, parent(zone.origin)))
        except ZoneError, e:
            logger.warn(str(e))

        # freeze the zone
        zone.freeze()
        
        # refresh the frozen zone, and make sure we still have a valid state
        zone.refresh_zone_info(included_ksks)
        zone_state.advance(zone, next_state, True)

        # get the max_ttl from the previous version of the zone
        max_ttl = zone.max_ttl

        zone.active_ksks.remove(old_ksk)
        zone.active_zsks.remove(old_zsk)
        zone.import_unpublished_ksk(old_ksk, move=True)
        zone.import_unpublished_zsk(old_zsk, move=True, gid=self.named_gid)

        # sign the zone with the previously-published ZSK
        console_logger.info('  Signing %s: %s' % (zone.origin, zone.zone_file))
        flush_handler('console')
        zone.sign_zone(included_ksks=included_ksks, nsec3=nsec3, nsec3_iter=nsec3_iter, nsec3_optout=nsec3_optout,
                verify_sign=verify_sign, randomdev=self.randomdev,
                prand=prand, gen_ds_rrs=self.gen_ds_rrs, uid=self.named_uid, gid=self.named_gid)

        # reload the zone
        zone.reload()

        wait_secs = self.propagation_time + max_ttl
        expire_secs = time.mktime(time.localtime()) + wait_secs
        expire_time = time.localtime(expire_secs)
        zone_state = zone.to_state(next_state, expire_time)
        zone_log.write_state(zone_state)

        return zone_state

    def _rollalg_remove_rrsigs(self, zone, zone_state, zone_log, algorithm, zsk_bits=None, prand=False, verify_sign=True):
        """Follow procedure for rolling algorithm following RFC 4641."""

        # identify additional KSKs that should be published
        included_ksks = self.published_ksks_from_other_views(zone)

        next_state = 'signed'
        # make sure the state transition is valid
        zone_state.advance(zone, next_state, None)

        # for simplicity ensure that the zone has exactly one of unpublished keys
        if len(zone.active_zsks) != 1:
            raise StateTransitionError('There must exactly one active ZSK for %s when resuming an algorithm rollover.' % zone.origin)
        if len(zone.active_ksks) != 1:
            raise StateTransitionError('There must exactly one active KSK for %s when resuming an algorithm rollover.' % zone.origin)
        if len(zone.unpublished_zsks) != 1:
            raise StateTransitionError('There must exactly one unpublished ZSK for %s when resuming an algorithm rollover.' % zone.origin)
        if len(zone.unpublished_ksks) != 1:
            raise StateTransitionError('There must exactly one unpublished KSK for %s when resuming an algorithm rollover.' % zone.origin)

        if zsk_bits is None:
            zsk_bits = zone.active_zsks[0].key_len()

        generated_keys = []
        pre_sign_time = time.localtime()
        try:
            # wait for current state to expire
            logger.info('Entering remove RRSIGs phase of algorithm rollover for %s...' % zone)
            flush_handler('console')
            zone_state.advance(zone, next_state, True)

            # generate the published ZSK, if it doesn't
            # already exist
            console_logger.info('  Generating published ZSK...')
            flush_handler('console')
            zsk_pub_file = gen_zsk(zone.origin, algorithm, zsk_bits, self.randomdev)
            zsk_pub_obj = DNSSECKey.from_file(zsk_pub_file)
            generated_keys.append(zsk_pub_obj)
            console_logger.info('  New published ZSK: %s' % zsk_pub_obj.filename())

            # freeze the zone
            zone.freeze(frozen_ok=True)
            
            # refresh the frozen zone, and make sure we still have a valid state
            zone.refresh_zone_info(included_ksks)
            zone_state.advance(zone, next_state, True)

            # swap unpublished/active keys
            old_unpub_zsk = zone.unpublished_zsks.pop()
            old_unpub_ksk = zone.unpublished_ksks.pop()
            zone.import_published_zsk(zsk_pub_obj, move=(zsk_pub_obj in generated_keys))

            # sign the zone with the previously-published ZSK
            console_logger.info('  Signing %s: %s' % (zone.origin, zone.zone_file))
            flush_handler('console')
            zone.sign_zone(included_ksks=included_ksks, verify_sign=verify_sign, randomdev=self.randomdev, prand=prand,
                    gen_ds_rrs=self.gen_ds_rrs, uid=self.named_uid, gid=self.named_gid)

            # reload the zone
            zone.reload()

            # thaw the zone
            zone.thaw()

            wait_secs = self.propagation_time + zone.max_key_ttl
            expire_secs = time.mktime(time.localtime()) + wait_secs
            expire_time = time.localtime(expire_secs)
            zone_state = zone.to_state(next_state, expire_time)
            zone_log.write_state(zone_state)

            # archive previously published keys
            for key in old_unpub_zsk, old_unpub_ksk:
                logger.info('  Archiving key previously unpublished in %s: %s' % (zone, key.filename()))
                self.archive_key(key, zone)

            return zone_state

        except:
            try:
                if not os.path.exists(zone.zone_file) or \
                        os.path.getmtime(zone.zone_file) < pre_sign_time:
                    for key in generated_keys:
                        key.remove_files()
            except:
                logger.exception('Error cleaning up keys')
            raise

    def rollzsk(self, origin, view=None, **kwargs):
        if view is None:
            view = self.default_view

        zone_log = self.get_zone_log(origin, view=view, write=True)
        zone = self.get_zone(origin, view=view, write=True)
        self._rollzsk(zone, zone_log, **kwargs)

    rollzsk.modifies_zone = True

    def _rollzsk(self, zone, zone_log, prand=False,
            zsk_pub_file=None, zsk_bits=None, verify_sign=True, block_after_first=True):
        """Follow procedure for rolling zsk using the pre-published key method."""

        # check existence/readability of key files supplied
        for path in (zsk_pub_file,):
            if path is None:
                continue
            path = strip_key_suffix(path)
            for ext in DNSKEY_SUFFIXES:
                self.file_readable(path+ext, 'Key file')

        zone_state = zone_log.current_state()
        # make sure we have a valid state
        if zone_state is None:
            raise ConfigurationError('Current state of %s unknown.' % zone)

        valid = False
        if zone_state.name == 'signed':
            zone_state = self._rollzsk_new_rrsigs(zone, zone_state, zone_log,
                    prand=prand, verify_sign=verify_sign, block=(not valid or block_after_first))
            valid = True

        if zone_state.name == 'zsk-pproll-wait-ttl':
            zone_state = self._rollzsk_new_dnskey(zone, zone_state, zone_log,
                    prand=prand, zsk_pub_file=zsk_pub_file, zsk_bits=zsk_bits,
                    verify_sign=verify_sign, block=(not valid or block_after_first))
            valid = True

        if not valid:
            raise StateTransitionError('Zone %s in unsuitable state "%s" for ZSK rollover.' % (zone, zone_state.name))

    def _rollzsk_new_rrsigs(self, zone, zone_state, zone_log, prand=False,
            verify_sign=True, block=True):
        """Follow procedure for rolling zsk using the pre-published key method."""

        # identify additional KSKs that should be published
        included_ksks = self.published_ksks_from_other_views(zone)

        next_state = 'zsk-pproll-wait-ttl'
        # make sure the state transition is valid
        zone_state.advance(zone, next_state, None)

        # for simplicity ensure that the zone has exactly one active ZSK and published ZSK
        if len(zone.active_zsks) != 1:
            raise StateTransitionError('There must be exactly one active ZSK for %s when initiating a ZSK rollover.' % zone.origin)
        if len(zone.published_zsks) != 1:
            raise StateTransitionError('There must be exactly one published ZSK for %s when initiating a ZSK rollover.' % zone.origin)

        if block:
            # wait for current state to expire, if in blocking mode
            logger.info('Entering new RRSIGs phase of ZSK PP-key rollover for %s...' % zone)
            flush_handler('console')
            zone_state.advance(zone, next_state, block)
        else:
            zone_state.advance(zone, next_state, block)
            logger.info('Entering new RRSIGs phase of ZSK PP-key rollover for %s...' % zone)
            flush_handler('console')

        # disable maintenance, and freeze the zone
        self._disable_maintenance_alarm()
        zone.freeze()

        try:
            # refresh the frozen zone, and make sure we still have a valid state
            zone.refresh_zone_info(included_ksks)
            zone_state.advance(zone, next_state, block)

            # get the max_ttl from the previous version of the zone
            max_ttl = zone.max_ttl

            # swap the file locations of the active key and the published key
            old_pub_zsk = zone.published_zsks.pop()
            old_active_zsk = zone.active_zsks.pop()
            zone.import_active_zsk(old_pub_zsk, move=True, gid=self.named_gid)
            zone.import_published_zsk(old_active_zsk, move=True)

            # sign the zone with the previously-published ZSK
            console_logger.info('  Signing %s: %s' % (zone.origin, zone.zone_file))
            flush_handler('console')
            zone.sign_zone(included_ksks=included_ksks, verify_sign=verify_sign, randomdev=self.randomdev, prand=prand,
                    gen_ds_rrs=self.gen_ds_rrs, uid=self.named_uid, gid=self.named_gid)

            # reload the zone
            zone.reload()

            wait_secs = self.propagation_time + max_ttl
            expire_secs = time.mktime(time.localtime()) + wait_secs
            expire_time = time.localtime(expire_secs)
            zone_state = zone.to_state(next_state, expire_time)
            zone_log.write_state(zone_state)

            return zone_state

        finally:
            # thaw the zone
            zone.thaw()
            self._enable_maintenance_alarm()

    def _rollzsk_new_dnskey(self, zone, zone_state, zone_log,
            prand=False, zsk_pub_file=None, zsk_bits=None,
            verify_sign=True, block=True):
        """Follow procedure for rolling zsk using the pre-published key method."""

        # identify additional KSKs that should be published
        included_ksks = self.published_ksks_from_other_views(zone)

        next_state = 'signed'
        # make sure the state transition is valid
        zone_state.advance(zone, next_state, None)

        # for simplicity ensure that the zone has exactly one active ZSK and published ZSK
        if len(zone.active_zsks) != 1:
            raise StateTransitionError('There must be exactly one active ZSK for %s when resuming a ZSK rollover.' % zone.origin)
        if len(zone.published_zsks) != 1:
            raise StateTransitionError('There must be exactly one published ZSK for %s when resuming a ZSK rollover.' % zone.origin)

        # save the old key away for archival
        old_zsk_pub = zone.published_zsks[0]

        algorithm = DNSKEY_ALGORITHMS.get(zone.active_zsks[0].algorithm, 'Unknown')
        if zsk_bits is None:
            zsk_bits = zone.published_zsks[0].key_len()

        generated_keys = []
        pre_sign_time = time.localtime()
        try:
            # wait for current state to expire, if in blocking mode
            if block:
                logger.info('Entering new DNSKEY phase of ZSK PP-key rollover for %s...' % zone)
                flush_handler('console')
                zone_state.advance(zone, next_state, block)
            else:
                zone_state.advance(zone, next_state, block)
                logger.info('Entering new DNSKEY phase of ZSK PP-key rollover for %s...' % zone)
                flush_handler('console')

            # generate the published ZSK, if it doesn't
            # already exist
            if zsk_pub_file is None:
                console_logger.info('  Generating published ZSK...')
                flush_handler('console')
                zsk_pub_file = gen_zsk(zone.origin, algorithm, zsk_bits, self.randomdev)
                zsk_pub_obj = DNSSECKey.from_file(zsk_pub_file)
                generated_keys.append(zsk_pub_obj)
                console_logger.info('  New published ZSK: %s' % zsk_pub_obj.filename())
            else:
                zsk_pub_obj = DNSSECKey.from_file(zsk_pub_file)

            # disable maintenance, and freeze the zone
            self._disable_maintenance_alarm()
            zone.freeze()

            try:
                # refresh the frozen zone, and make sure we still have a valid state
                zone.refresh_zone_info(included_ksks)
                zone_state.advance(zone, next_state, block)

                # import the new key
                zone.published_zsks.remove(old_zsk_pub)
                zone.import_published_zsk(zsk_pub_obj, move=(zsk_pub_obj in generated_keys))

                # sign the zone with the previously-published ZSK
                console_logger.info('  Signing %s: %s' % (zone.origin, zone.zone_file))
                flush_handler('console')
                zone.sign_zone(included_ksks=included_ksks, verify_sign=verify_sign, randomdev=self.randomdev, prand=prand,
                        gen_ds_rrs=self.gen_ds_rrs, uid=self.named_uid, gid=self.named_gid)

                # since the zone is signed, the generated_keys are now in use
                generated_keys = []

                # reload the zone
                zone.reload()

                wait_secs = self.propagation_time + zone.max_key_ttl
                expire_secs = time.mktime(time.localtime()) + wait_secs
                expire_time = time.localtime(expire_secs)
                zone_state = zone.to_state(next_state, expire_time)
                zone_log.write_state(zone_state)

                # archive the old ZSK
                logger.info('  Archiving ZSK previously active in %s: %s' % (zone, old_zsk_pub.filename()))
                self.archive_key(old_zsk_pub, zone)

                return zone_state

            finally:
                # thaw the zone
                zone.thaw()
                self._enable_maintenance_alarm()

        except:
            try:
                if not os.path.exists(zone.zone_file) or \
                        os.path.getmtime(zone.zone_file) < pre_sign_time:
                    for key in generated_keys:
                        key.remove_files()
            except:
                logger.exception('Error cleaning up keys')
            raise

    def rollksk(self, origin, view=None, **kwargs):
        if view is None:
            view = self.default_view

        zone_log = self.get_zone_log(origin, view=view, write=True)
        zone = self.get_zone(origin, view=view, write=True)
        self._rollksk(zone, zone_log, **kwargs)

    rollksk.modifies_zone = True
    
    def _rollksk(self, zone, zone_log, prand=False,
            ksk_file=None, ksk_bits=None, verify_sign=True, block_after_first=True):
        """Follow procedure for rolling ksk using the double-signature key method."""

        # check existence/readability of key files supplied
        for path in (ksk_file,):
            if path is None:
                continue
            path = strip_key_suffix(path)
            for ext in DNSKEY_SUFFIXES:
                self.file_readable(path+ext, 'Key file')

        zone_state = zone_log.current_state()
        # make sure we have a valid state
        if zone_state is None:
            raise ConfigurationError('Current state of %s unknown.' % zone)

        valid = False
        if zone_state.name == 'signed':
            zone_state = self._rollksk_new_dnskey(zone, zone_state, zone_log,
                    prand=prand, ksk_file=ksk_file, ksk_bits=ksk_bits,
                    verify_sign=verify_sign, block=(not valid or block_after_first))
            valid = True

        if zone_state.name == 'ksk-dsroll-wait-dschange':
            zone_state = self._rollksk_ds_change(zone, zone_state, zone_log, block=(not valid or block_after_first))
            valid = True

        if zone_state.name == 'ksk-dsroll-wait-dsttl':
            zone_state = self._rollksk_dnskey_removal(zone, zone_state, zone_log,
                    prand=prand, verify_sign=verify_sign, block=(not valid or block_after_first))
            valid = True

        if not valid:
            raise StateTransitionError('Zone %s in unsuitable state "%s" for KSK rollover.' % \
                    (zone, zone_state.name))

    def _rollksk_new_dnskey(self, zone, zone_state, zone_log,
            prand=False, ksk_file=None, ksk_bits=None,
            verify_sign=True, block=True):

        # identify additional KSKs that should be published
        included_ksks = self.published_ksks_from_other_views(zone)

        next_state = 'ksk-dsroll-wait-dschange'
        # make sure the state transition is valid
        zone_state.advance(zone, next_state, None)

        # for simplicity ensure that the zone has exactly one active KSK and no published KSK
        if len(zone.active_ksks) != 1:
            raise StateTransitionError('There must be exactly one active KSK for %s when initiating a KSK rollover.' % zone.origin)
        if len(zone.published_ksks) > 0:
            raise StateTransitionError('No published KSKs may exist for %s when initiating a KSK rollover.' % zone.origin)

        algorithm = DNSKEY_ALGORITHMS.get(zone.active_ksks[0].algorithm, 'Unknown')
        if ksk_bits is None:
            ksk_bits = zone.active_ksks[0].key_len()

        generated_keys = []
        pre_sign_time = time.localtime()
        try:
            # wait for current state to expire, if in blocking mode
            if block:
                logger.info('Entering new DNSKEY phase of KSK rollover for %s...' % zone)
                flush_handler('console')
                zone_state.advance(zone, next_state, block)
            else:
                zone_state.advance(zone, next_state, block)
                logger.info('Entering new DNSKEY phase of KSK rollover for %s...' % zone)
                flush_handler('console')

            # generate the KSK, if it doesn't
            # already exist
            if ksk_file is None:
                console_logger.info('  Generating KSK...')
                flush_handler('console')
                ksk_file = gen_ksk(zone.origin, algorithm, ksk_bits, self.randomdev)
                ksk_obj = DNSSECKey.from_file(ksk_file)
                generated_keys.append(ksk_obj)
                console_logger.info('  New KSK: %s' % ksk_obj.filename())
            else:
                ksk_obj = DNSSECKey.from_file(ksk_file)

            # disable maintenance, freeze the zone
            self._disable_maintenance_alarm()
            zone.freeze()

            try:
                # refresh the frozen zone, and make sure we still have a valid state
                zone.refresh_zone_info(included_ksks)
                zone_state.advance(zone, next_state, block)

                # import the new key
                zone.import_active_ksk(ksk_obj, move=(ksk_obj in generated_keys))

                # sign the zone
                console_logger.info('  Signing %s: %s' % (zone.origin, zone.zone_file))
                flush_handler('console')
                zone.sign_zone(included_ksks=included_ksks, verify_sign=verify_sign, randomdev=self.randomdev, prand=prand,
                        gen_ds_rrs=self.gen_ds_rrs, uid=self.named_uid, gid=self.named_gid)

                # since the zone is signed, the generated_keys are now in use
                generated_keys = []

                # reload the zone
                zone.reload()

                zone_state = zone.to_state(next_state, time.localtime())

                zone_log.write_state(zone_state)

                return zone_state

            finally:
                # thaw the zone
                zone.thaw()
                self._enable_maintenance_alarm()

        except:
            try:
                if not os.path.exists(zone.zone_file) or \
                        os.path.getmtime(zone.zone_file) < pre_sign_time:
                    for key in generated_keys:
                        key.remove_files()
            except:
                logger.exception('Error cleaning up keys')
            raise

    def _rollksk_ds_change(self, zone, zone_state, zone_log, block=True):

        # resign any zones in views which publish these KSKs
        self.resign_affected_zones(zone)

        if block:
            logger.info('Entering DS change phase of KSK rollover for %s...' % zone)
            flush_handler('console')

        next_state = 'ksk-dsroll-wait-dsttl'
        # make sure the state transition is valid
        zone_state.advance(zone, next_state, block)

        if not block:
            logger.info('Entering DS change phase of KSK rollover for %s...' % zone)
            flush_handler('console')

        wait_secs = self._update_ds(zone)
        expire_secs = time.mktime(time.localtime()) + wait_secs
        expire_time = time.localtime(expire_secs)
        zone_state = zone.to_state(next_state, expire_time)
        zone_log.write_state(zone_state)

        return zone_state

    def _rollksk_dnskey_removal(self, zone, zone_state, zone_log,
            prand=False, verify_sign=True, block=True):

        # identify additional KSKs that should be published
        included_ksks = self.published_ksks_from_other_views(zone)

        next_state = 'signed'
        # make sure the state transition is valid
        zone_state.advance(zone, next_state, None)

        # for simplicity ensure that the zone has exactly two active KSKs and no published KSKs
        if len(zone.active_ksks) != 2:
            raise StateTransitionError('There must be exactly two active KSKs for %s when resuming a ZSK rollover.' % zone.origin)
        if len(zone.published_ksks) > 0:
            raise StateTransitionError('No published KSKs may exist for %s when resuming a KSK rollover.' % zone.origin)

        # find out which key was published first, and that one will be removed
        pub0,act0 = zone_log.key_info(zone.active_ksks[0].filename())
        pub1,act1 = zone_log.key_info(zone.active_ksks[1].filename())
        if pub0 < pub1:
            old_ksk = zone.active_ksks[0]
            ksk_obj = zone.active_ksks[1]
        else:
            old_ksk = zone.active_ksks[1]
            ksk_obj = zone.active_ksks[0]

        # wait for current state to expire, if in blocking mode
        if block:
            logger.info('Entering DNSKEY removal phase of KSK rollover for %s...' % zone)
            flush_handler('console')
            zone_state.advance(zone, next_state, block)
        else:
            zone_state.advance(zone, next_state, block)
            logger.info('Entering DNSKEY removal phase of KSK rollover for %s...' % zone)
            flush_handler('console')

        # query for new DS key to be sure it exists
        try:
            ds_ttl = zone.ds_ttl()
            if ds_ttl is not None:
                ds_exists, rrsig_exists = zone.ds_exists(ksk_obj)
                if not ds_exists:
                    # revert to wait DS change state, and raise an error
                    zone_state = zone.to_state('ksk-dsroll-wait-dschange', time.localtime())
                    zone_log.write_state(zone_state)
                    raise ConfigurationError('DS RR for new KSK %s does not exist (was it properly added to the %s zone?)\nPlease try the KSK rollover again.' %
                            (ksk_obj, parent(zone.origin)))
        except ZoneError, e:
            logger.warn(str(e))

        # disable maintenance, and freeze the zone
        self._disable_maintenance_alarm()
        zone.freeze()

        try:
            # refresh the frozen zone, and make sure we still have a valid state
            zone.refresh_zone_info(included_ksks)
            zone_state.advance(zone, next_state, block)

            zone.active_ksks.remove(old_ksk)

            # sign the zone
            console_logger.info('  Signing %s: %s' % (zone.origin, zone.zone_file))
            flush_handler('console')
            zone.sign_zone(included_ksks=included_ksks, verify_sign=verify_sign, randomdev=self.randomdev, prand=prand,
                    gen_ds_rrs=self.gen_ds_rrs, uid=self.named_uid, gid=self.named_gid)

            # reload the zone
            zone.reload()

            zone_state = zone.to_state(next_state, time.localtime())
            zone_log.write_state(zone_state)

            # archive the old KSK
            logger.info('  Archiving KSK previously active in %s: %s' % (zone, old_ksk.filename()))
            self.archive_key(old_ksk, zone)

            return zone_state

        finally:
            # thaw the zone
            zone.thaw()
            self._enable_maintenance_alarm()

    def list(self):
        managed_zones = []
        unmanaged_zones = []
        for origin in self.named_conf_obj.zones.keys():
            for cls, view in self.named_conf_obj.zones[origin]:

                zone_type = self.named_conf_obj.zone_type(origin,cls,view)
                if zone_type is None or zone_type.lower() != 'master':
                    continue

                managed = True
                try:
                    zone_log = self.get_zone_log(origin, view=view)
                    zone_state = zone_log.current_state()
                except ZoneNotManaged:
                    zone_log = None
                    zone_state = None
                    managed = False
                except LogError, e:
                    zone_log = None
                    zone_state = None
                    logger.error('Unreadable log file for %s: %s' % (zone_str(origin, cls, view), e))

                if managed:
                    managed_zones.append((zone_str(origin, cls, view), zone_state))
                else:
                    unmanaged_zones.append(zone_str(origin, cls, view))

        if managed_zones:
            sys.stdout.write('Managed zones:\n')
            for zone, zone_state in managed_zones:
                if zone_state is None:
                    sys.stdout.write('  %s\n' % (zone))
                else:
                    if time.localtime() < zone_state.expire:
                        expire_str = ', immutable until %s' % (time.strftime('%x %X', zone_state.expire))
                    else:
                        expire_str = ''
                    sys.stdout.write('  %s (state %s%s)\n' % (zone, zone_state.name, expire_str))
        if unmanaged_zones:
            sys.stdout.write('Unmanaged zones:\n')
            for zone in unmanaged_zones:
                sys.stdout.write('  %s\n' % (zone))

    def maintenance(self, prand=False, show_only=False, background=False):
        """Perform routine maintenance on each of the zones in the named.conf, depending on the state of each."""

        if show_only:
            disable_handler('syslog')
            disable_handler('email')

        # create maintenance queues
        resign_queue = []
        keyroll_queue = []

        managed_zones = []
        unmanaged_zones = []
        for origin in self.named_conf_obj.zones.keys():
            for cls, view in self.named_conf_obj.zones[origin]:

                zone_log = None
                zone_type = self.named_conf_obj.zone_type(origin,cls,view)
                if zone_type is None or zone_type.lower() != 'master':
                    continue

                managed = True
                try:
                    zone_log = self.get_zone_log(origin, view=view, write=True)
                    zone_state = zone_log.current_state()
                except ZoneNotManaged:
                    zone_log = None
                    zone_state = None
                    managed = False
                except LogWriteError, e:
                    zone_log = None
                    zone_state = None
                    logger.error(str(e))
                except LogLockError, e:
                    zone_log = None
                    zone_state = None
                    logger.warn(str(e))
                except LogError, e:
                    zone_log = None
                    zone_state = None
                    logger.error('Unreadable log file for %s: %s' % (zone_str(origin, cls, view), e))

                if not managed:
                    unmanaged_zones.append(zone_str(origin, cls, view))
                    continue

                try:
                    zone = self.get_zone(origin, view=view, write=True)
                except ZoneToolError, e:
                    logger.error('Error reading %s: %s' % (zone_str(origin, cls, view), e))
                    continue

                managed_zones.append(zone)

                # if the zone is managed, but we couldn't read the state file
                # then move to the next zone
                if zone_state is None:
                    continue

                try:
                    zone_state.check_keys(zone)
                except InconsistentKeys, e:
                    logger.error('State of zone %s is corrupt: %s' % (zone, e))
                    continue

                # queue zones with signatures expiring within the window
                if datetime.datetime(*zone.min_expire_dt[0:6]) - datetime.datetime.now() <= self.sig_renewal_window:
                    resign_queue.append((zone,zone_log))
                    logger.info('Zone %s scheduled to be re-signed...' % zone)
                # for static zones, if there is a new serial in the unsigned version,
                # then queue it for resigning
                elif not zone.is_dynamic and zone.unsigned_serial > zone_state.unsigned_serial:
                    resign_queue.append((zone,zone_log))
                    logger.info('Zone %s scheduled to be re-signed...' % zone)

                # check for intermediate states--signs of incomplete maintenance
                if zone_state.name != 'signed':
                    if zone_state.name in ('zsk-pproll-wait-ttl',):
                        keyroll_queue.append((zone,zone_log,self._rollzsk))
                        logger.info('Zone %s scheduled to resume ZSK rollover...' % zone)
                    elif zone_state.name in ('ksk-dsroll-wait-dschange', 'ksk-dsroll-wait-dsttl'):
                        keyroll_queue.append((zone,zone_log,self._rollksk))
                        logger.info('Zone %s scheduled to resume KSK rollover...' % zone)
                    else:
                        logger.error('Zone %s found in unrecognized state "%s"' % (zone, zone_state.name))

                if (zone,zone_log,self._rollzsk) not in keyroll_queue:
                    # queue ZSK rollovers
                    for key in zone.active_zsks:
                        pub_date, active_date = zone_log.key_info(key.filename())
                        if active_date is None:
                            logger.error('Unable to determine activation time for ZSK %s of zone %s' % (key, zone))
                            continue
                        if datetime.datetime.now() - datetime.datetime(*active_date[0:6]) >= self.zsk_expiration:
                            keyroll_queue.append((zone,zone_log,self._rollzsk))
                            logger.info('Zone %s scheduled to initiate ZSK rollover...' % zone)
                            break
                        
                if (zone,zone_log,self._rollksk) not in keyroll_queue:
                    # queue KSK rollovers
                    for key in zone.active_ksks:
                        pub_date, active_date = zone_log.key_info(key.filename())
                        if active_date is None:
                            logger.error('Unable to determine activation time for KSK %s of zone %s' % (key, zone))
                            continue
                        if datetime.datetime.now() - datetime.datetime(*active_date[0:6]) >= self.ksk_expiration:
                            keyroll_queue.append((zone,zone_log,self._rollksk))
                            logger.info('Zone %s scheduled to initiate KSK rollover...' % zone)
                            break

        # complain if there were no managed zones
        if not managed_zones:
            raise ConfigurationError('No managed zones found!  Found only the following: \n  %s' % \
                    ('\n  '.join([str(zone) for zone in unmanaged_zones])))

        # if a zone is not scheduled for maintenance, then remove
        # its log from cache, so it lock out other processes from
        # later making changes
        del zone_log
        self._del_unreferenced_cache_entries()

        if not resign_queue and not keyroll_queue:
            if settings.values['global'].get('quiet', 'yes').lower() not in ('no', 'false'):
                set_handler_log_level('email', logging.WARNING)
            logger.info('No zone maintenance required.')
            if settings.values['global'].get('quiet', 'yes').lower() not in ('no', 'false'):
                set_handler_log_level('email', logging.DEBUG)
            return

        # if we're not actually doing any of the maintenance, then exit
        if show_only:
            return

        if background:
            console_logger.info('Backgrounding for maintenance...')
            daemonize()

        flush_handler('email')

        # handle zones to be resigned
        for zone, zone_log in resign_queue:
            try:
                self._resign(zone, zone_log, prand=prand)
            except ZoneToolError, e:
                logger.error(str(e))
            except KeyboardInterrupt:
                raise
            except:
                logger.exception('Error while resigning %s' % zone)
        del resign_queue

        # set an alarm for one day from now to check for expiring sigs
        # in queued zones, so signatures don't expire while zones
        # are waiting to be serviced
        self._initialize_maintenance_alarm(86400)

        # ZSK/KSK rollovers
        check_sigs = False
        while keyroll_queue:
            if check_sigs:
                # check for any queued zones that need to be resigned
                checked_zones = []
                for zone, zone_log, func in keyroll_queue:
                    if zone in checked_zones:
                        continue
                    checked_zones.append(zone)
                    if not (datetime.datetime(*zone.min_expire_dt[0:6]) - datetime.datetime.now() <= self.sig_renewal_window):
                        continue
                    # re-sign zones with signatures expiring within the window
                    try:
                        self._resign(zone, zone_log, prand=prand, block=False)
                    except ZoneToolError, e:
                        logger.error(str(e))
                    except KeyboardInterrupt:
                        raise
                    except:
                        logger.exception('Error while resigning %s' % zone)
                check_sigs = False
                # reset the alarm
                self._initialize_maintenance_alarm(86400)

            self._enable_maintenance_alarm()
            try:
                # handle the zone in the state that expires soonest.
                # if both a zone is scheduled for both a ZSK and KSK
                # rollover, the ZSK rollover is handled first
                keyroll_queue.sort(cmp=self._zone_tuple_cmp)
                zone, zone_log, func = keyroll_queue[0]
                func(zone, zone_log, prand=prand, block_after_first=False)
            except StateNotExpired:
                continue
            except MaintenanceNeeded:
                check_sigs = True
                continue
            except InteractionNeeded:
                console_logger.error('''******************************************************''')
                logger.error('Interaction needed to complete maintenance of %s.\nPlease re-run maintenance in the foreground from an interactive shell:\n%s maintenance' % (zone, sys.argv[0]))
                console_logger.error('''******************************************************''')
            except ZoneToolError, e:
                logger.error(str(e))
            except KeyboardInterrupt:
                raise
            except:
                logger.exception('Error while performing key rollover on %s' % zone)
            keyroll_queue.remove((zone, zone_log, func))
            self._del_unreferenced_cache_entries()

    maintenance.modifies_zone = True

    def _del_unreferenced_cache_entries(self):
        import gc
        import inspect

        cached_logs = self._zone_log_cache.items()
        for item in cached_logs:
            referrers = gc.get_referrers(item[1])
            count = len(referrers)
            if self._zone_log_cache in referrers:
                count -= 1
            if item in referrers:
                count -= 1
            if inspect.currentframe() in referrers:
                count -= 1

            if not count:
                del self._zone_log_cache[item[0]]

    def _zone_tuple_cmp(self, x, y):
        '''Compares a (Zone, ZoneLog) tuple with another and returns the
        tuple with the soonest state expiration.'''

        zone_x, zone_log_x, func_x = x
        zone_y, zone_log_y, func_y = y
        if zone_x == zone_y:
            # if this is a queued ZSK rollover
            if func_x == self._rollzsk:
                # if a KSK rollover is already in process, then make that first
                if zone_log_x.current_state().name in ('ksk-dsroll-wait-dschange', 'ksk-dsroll-wait-dsttl'):
                    return 1
                # otherwise, give preference to the ZSK rollover
                return -1
            else: # func == self._rollksk
                # if a KSK rollover is already in process, then make that first
                if zone_log_x.current_state().name in ('ksk-dsroll-wait-dschange', 'ksk-dsroll-wait-dsttl'):
                    return -1
                # otherwise, give preference to the ZSK rollover
                return 1

        expire_x = zone_log_x.current_state().expire
        expire_y = zone_log_y.current_state().expire
        return int(time.mktime(expire_x) - time.mktime(expire_y))

    def _disable_maintenance_alarm(self):
        if self.maintenance_alarm is None:
            return
        signal.alarm(0)

    def _enable_maintenance_alarm(self):
        if self.maintenance_alarm is None:
            return
        alarm_secs = time.mktime(self.maintenance_alarm) - time.mktime(time.localtime())
        if alarm_secs <= 0:
            alarm_secs = 1
        signal.alarm(int(alarm_secs))

    def _initialize_maintenance_alarm(self, secs):
        def _alarm_handler(signum, frame):
            raise MaintenanceNeeded
        signal.signal(signal.SIGALRM, _alarm_handler)
        self.maintenance_alarm = time.localtime(time.mktime(time.localtime()) + secs)
        self._enable_maintenance_alarm()

    def upgrade(self, show_only=False):
        """upgrade log versions"""

        log_tmp_file = None
        try:
            fd, log_tmp_file = tempfile.mkstemp('', 'zone_log')
            os.close(fd)

            for origin in self.named_conf_obj.zones.keys():
                for cls, view in self.named_conf_obj.zones[origin]:

                    zone_type = self.named_conf_obj.zone_type(origin,cls,view)
                    if zone_type is None or zone_type.lower() != 'master':
                        continue

                    needs_upgrade = False
                    try:
                        zone_log = self.get_zone_log(origin, view=view, write=True)
                    except LogVersionError, e:
                        needs_upgrade = True
                        previous_version = e.old_version
                    except (ZoneNotManaged, LogError):
                        pass

                    if not needs_upgrade:
                        continue

                    zone = self.get_zone(origin, view=view)
                    log_file = os.path.join(self.zone_dir(origin, view), ZONE_LOG_FILE)
                    log_version_file = os.path.join(self.zone_dir(origin, view), ZONE_LOG_VERSION_FILE)

                    # obtain the lock on the zone log file
                    zone_log = ZoneLog(log_file)
                    zone_log.initialize_handle(write=True)

                    logger.info('Upgrading log file for %s' % (zone))

                    if show_only:
                        continue

                    if previous_version is None:
                        previous_version = 1

                    if previous_version == 1:
                        new_log_fh = open(log_tmp_file, 'w')
                        old_log_fh = open(log_file, 'r')

                        for line in old_log_fh:
                            line = line.rstrip()
                            fields = line.split('|')
                            fields[0] = fields[0].replace('ksk-dsroll-wait-ttl','ksk-dsroll-wait-dsttl')
                            for i in range(5,9):
                                if not fields[i]:
                                    continue
                                key_tags = map(int, fields[i].split(','))
                                filenames = ['K%s+%03d+%05d' % (zone.origin, zone.active_zsks[0].algorithm, tag) for tag in key_tags]
                                fields[i] = ','.join(filenames)
                            # insert two empty slots for unpublished ZSKs/KSKs
                            fields.insert(7,'')
                            fields.append('')
                            new_log_fh.write('|'.join(fields)+'\n')

                        # copy the new version of the log file
                        # and preserve permission bits
                        new_log_fh.close()
                        console_logger.debug('cp %s %s' % (log_tmp_file,log_file))
                        shutil.copymode(log_file, log_tmp_file)
                        shutil.copy(log_tmp_file, log_file)
                        open(log_version_file, 'w').write('2')

        finally:
            if log_tmp_file is not None: os.remove(log_tmp_file)
