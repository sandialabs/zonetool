#    Zonetool is a utility for signing and maintaining DNSSEC zones and keys.
#
#    Copyright (2009) Sandia Corporation. Under the terms of Contract
#    DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
#    certain rights in this software.
#
#    This package is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This package is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License along
#    with this program; if not, write to the Free Software Foundation, Inc.,
#    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

import datetime
import os
import random
import re
import subprocess
import tempfile

from log import logger, console_logger
from util import tool_version, dig_query, check_zone, check_zone_disable_checking_args, CommandError

DNSKEY_SUFFIXES = ('.key','.private')

DNSSEC_NONKEY_RRTYPES = ('NSEC','NSEC3','NSEC3PARAM','NXT','RRSIG','SIG')
DNSSEC_KEY_RRTYPES = ('KEY','DNSKEY')

DNSKEY_FLAGS = {'ZSK': 0x0100, 'SEP': 0x0001, 'revoke': 0x0080}
DNSKEY_PROTOCOLS = { 'DNSSEC': 3 }
DNSKEY_ALGORITHMS = { 1: 'RSAMD5', 2: 'DH', 3: 'DSA', 5: 'RSASHA1', 6: 'NSEC3DSA', 7: 'NSEC3RSASHA1', 8: 'RSASHA256', 10: 'RSASHA512' }

NSEC3_FLAGS = {'OPTOUT': 0x01}

def canonicalize_name(name):
    '''Return a canonical form of the given name, as defined in RFC 4043.'''

    return name.lower().strip('.')+'.'

def strip_key_suffix(name):
    '''Return a string with any DNSSEC key suffixes stripped from end.'''

    for suffix in DNSKEY_SUFFIXES:
        if name.endswith(suffix):
            return name[:-len(suffix)]
    if name.endswith('.'):
        return name[:-1]
    return name

def canonicalize_zone(origin, zone_file, chroot='', checkzone_args=[]):
    '''Check syntax of a zone, create a file safely in a temporary location,
    and write the canonical version of the zone to the temporary file
    (RFC 4043, section 6).'''

    checkzone_args = checkzone_args[:]

    zone_tmp_file = None
    try:
        # safely create a temporary file for the clean output
        if chroot:
            fd, zone_tmp_file = tempfile.mkstemp('', origin, chroot)
            output_file = zone_tmp_file.replace(chroot.rstrip(os.sep), '')
        else:
            fd, zone_tmp_file = tempfile.mkstemp('', origin)
            output_file = zone_tmp_file
        # close the file descriptor
        os.close(fd)

        # if using a chrooted environment, at the -t switch
        if chroot:
            checkzone_args += ['-t', chroot]

        checkzone_args += check_zone_disable_checking_args()

        # check the current zone file for syntax, and canonicalize it
        cmd = ['named-checkzone', '-D', '-o', output_file] + checkzone_args + [origin, zone_file]
        console_logger.debug(' '.join(cmd))
        try:
            checkzone = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, close_fds=True)
        except OSError, e:
            raise CommandError(str(e))
        if checkzone.wait() != 0:
            raise CommandError(checkzone.stdout.read())

        return zone_tmp_file

    # if there were any errors, clean up the temporary file,
    # and re-raise the exception
    except:
        if zone_tmp_file is not None:
            try:
                os.remove(zone_tmp_file)
            except:
                logger.exception('error removing temporary zone file')
        raise

def stage_zone(origin, zone_file, new_serial=0, chroot='', key_files=[], strip_dnssec_rrs=True):
    '''Stage a zone file for signing with DNSSEC.  Canonicalize the
    data in the zone file, strip all previous DNSSEC RRs, include
    key files, and check and return the resulting file.'''

    zone_tmp_file = None
    try:
        zone_tmp_file = canonicalize_zone(origin, zone_file, new_serial=new_serial, chroot=chroot, strip_dnssec_rrs=strip_dnssec_rrs)

        fh = open(zone_tmp_file, 'a')
        # add the include statements to the intermediate file
        for key_file in key_files:
            key_file = strip_key_suffix(key_file)
            fh.write('$INCLUDE "%s.key"\n' % key_file)
        # close the file
        fh.close()

        # disable checks
        checkzone_args = check_zone_disable_checking_args()

        # check the resulting file
        check_zone(origin, zone_tmp_file, checkzone_args=checkzone_args)

        return zone_tmp_file

    # if there were any errors, clean up the temporary file,
    # and re-raise the exception
    except:
        if zone_tmp_file is not None:
            try:
                os.remove(zone_tmp_file)
            except:
                logger.exception('error removing temporary zone file')
        raise


def gen_zsk(zone, algorithm, bits, randomdev=None, keygen_args=[]):
    '''Generate a ZONE-type key suitable for signing zones, and
    place it in the appropriate keys directory.'''

    keygen_args = keygen_args[:]
    if randomdev is not None:
        keygen_args += ['-r',randomdev]

    # for BIND >= 9.7 use -q, to suppress progress meter
    version = tool_version('named-checkconf','-v')
    try:
        vers = int(version['vers'])
        major = int(version['major'])
        if vers >=9 and major >= 7:
            keygen_args += ['-q']
    except ValueError:
        pass

    cmd = ['dnssec-keygen', '-a', algorithm, '-b', str(bits),
            '-n', 'ZONE'] + keygen_args + [zone]

    console_logger.debug(' '.join(cmd))
    try:
        keygen = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, close_fds=True)
    except OSError, e:
        raise CommandError(str(e))
    if keygen.wait() != 0:
        raise CommandError(keygen.stdout.read())
    key_file = keygen.stdout.read().strip()

    return key_file

def gen_ksk(zone, algorithm, bits, randomdev=None, keygen_args=[]):
    '''Generate a ZONE-type key suitable for signing zones with
    the KSK flag set, and place it in the appropriate keys directory.'''

    return gen_zsk(zone, algorithm, bits, 
            randomdev=randomdev, keygen_args=['-f', 'KSK']+keygen_args)

def ds_ttl(origin, dlv_domain=None):
    origin = canonicalize_name(origin)
    if dlv_domain is not None:
        origin += canonicalize_name(dlv_domain)
        rr_type = 'DLV'
    else:
        rr_type = 'DS'
    output = dig_query(origin, rr_type, dig_args=['+noall','+answer','+dnssec'])

    if not output:
        return None

    # if there is a signature, then use the orig TTL value from
    # the RRSIG
    for line in output.split('\n'):
        line = line.rstrip()
        (name, ttl, cls, rrtype, val) = line.split(None, 4)
        if (name, rrtype) != (origin, 'RRSIG'):
            continue
        (covered, algorithm, labels, orig_ttl, rest) = val.split(None, 4)
        if covered == rr_type:
            return int(orig_ttl)

    return None

def sign_zone(zone_file, zone, signed_zone_file, ksk_files=[], zsk_files=[], keyset_dir=None,
        interval=None, nsec3=False, nsec3_salt=-1, nsec3_iter=2, nsec3_optout=False, verify_sign=True,
        randomdev=None, prand=False, gen_ds_rrs=False, signzone_args=[]):
    '''Sign a zone with given KSKs and ZSKs.  If NSEC3 is
    desired, use the salt provided, or generate a random salt if value is -1.'''

    signzone_args = signzone_args[:]

    # add appropriate nsec3 options
    if nsec3:
        # if salt is -1, generate a random salt
        if nsec3_salt == -1:
            nsec3_salt = ''
            for i in range(3):
                nsec3_salt += '%02x' % random.randint(0, 255)
        # if salt is some other non-None value,
        # then convert it to a string
        elif nsec3_salt is not None:
            nsec3_salt = '%06x' % nsec3_salt
        # if salt is None, then don't use a salt
        else:
            nsec3_salt = '-'

        signzone_args += ['-3', nsec3_salt, '-H', str(nsec3_iter)]

        if nsec3_optout:
            signzone_args += ['-A']

    if verify_sign:
        signzone_args += ['-a']
    if prand:
        signzone_args += ['-p']
    if gen_ds_rrs:
        signzone_args += ['-g']
    if randomdev is not None:
        signzone_args += ['-r', randomdev]
    if keyset_dir is not None:
        signzone_args += ['-d', keyset_dir]
    if interval is not None:
        # convert interval to seconds
        if isinstance(interval, datetime.timedelta):
            interval = 3600*24*interval.days + interval.seconds
        signzone_args += ['-i', str(interval)]


    # for BIND >= 9.7 use -x, to avoid signing the DNSKEY RRset with the ZSK
    version = tool_version('named-checkconf','-v')
    try:
        vers = int(version['vers'])
        major = int(version['major'])
        if vers >=9 and major >= 7:
            signzone_args += ['-x']
    except ValueError:
        pass

    for key in ksk_files:
        signzone_args += ['-k',key]

    cmd = ['dnssec-signzone', '-f', signed_zone_file, '-o', zone] + signzone_args + [zone_file]

    for key in zsk_files:
        cmd.append(key)

    console_logger.debug(' '.join(cmd))
    try:
        signzone = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, close_fds=True)
    except OSError, e:
        raise CommandError(str(e))
    if not (signzone.wait() == 0 and os.path.exists(signed_zone_file) and os.path.getsize(signed_zone_file) > 0):
        raise CommandError(signzone.stdout.read())
