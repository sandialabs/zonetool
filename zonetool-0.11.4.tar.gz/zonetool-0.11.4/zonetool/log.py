#    Zonetool is a utility for signing and maintaining DNSSEC zones and keys.
#
#    Copyright (2009) Sandia Corporation. Under the terms of Contract
#    DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
#    certain rights in this software.
#
#    This package is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This package is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License along
#    with this program; if not, write to the Free Software Foundation, Inc.,
#    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

import logging
import os
import smtplib
import socket
import sys
import syslog

from errors import ZoneToolError
import settings

class ReportingError(ZoneToolError):
    pass

class NullHandler(logging.Handler):
    def emit(self, record):
        pass

class LocalSysLogHandler(logging.Handler):
    """
    A handler class which sends formatted logging records to syslog

    Some of this class is taken from logging/handlers.py in the python
    distribution.
    """

    priority_names = {
        "alert":    syslog.LOG_ALERT,
        "crit":     syslog.LOG_CRIT,
        "critical": syslog.LOG_CRIT,
        "debug":    syslog.LOG_DEBUG,
        "emerg":    syslog.LOG_EMERG,
        "err":      syslog.LOG_ERR,
        "error":    syslog.LOG_ERR,        #  DEPRECATED
        "info":     syslog.LOG_INFO,
        "notice":   syslog.LOG_NOTICE,
        "panic":    syslog.LOG_EMERG,      #  DEPRECATED
        "warn":     syslog.LOG_WARNING,    #  DEPRECATED
        "warning":  syslog.LOG_WARNING,
        }

    facility_names = {
        "auth":     syslog.LOG_AUTH,
        "cron":     syslog.LOG_CRON,
        "daemon":   syslog.LOG_DAEMON,
        "kern":     syslog.LOG_KERN,
        "lpr":      syslog.LOG_LPR,
        "mail":     syslog.LOG_MAIL,
        "news":     syslog.LOG_NEWS,
        "security": syslog.LOG_AUTH,       #  DEPRECATED
        "user":     syslog.LOG_USER,
        "uucp":     syslog.LOG_UUCP,
        "local0":   syslog.LOG_LOCAL0, "local1":   syslog.LOG_LOCAL1,
        "local2":   syslog.LOG_LOCAL2,
        "local3":   syslog.LOG_LOCAL3,
        "local4":   syslog.LOG_LOCAL4,
        "local5":   syslog.LOG_LOCAL5,
        "local6":   syslog.LOG_LOCAL6,
        "local7":   syslog.LOG_LOCAL7,
        }

    #The map below appears to be trivially lowercasing the key. However,
    #there's more to it than meets the eye - in some locales, lowercasing
    #gives unexpected results. See SF #1524081: in the Turkish locale,
    #"INFO".lower() != "info"
    priority_map = {
        "DEBUG" : "debug",
        "INFO" : "info",
        "WARNING" : "warning",
        "ERROR" : "error",
        "CRITICAL" : "critical"
    }

    def __init__(self, ident, logopt=0, facility=syslog.LOG_USER):
        logging.Handler.__init__(self)
        if not isinstance(facility, int):
            facility = self.facility_names.get(facility, syslog.LOG_USER)
        syslog.openlog(ident, logopt, facility)

    def close(self):
        syslog.closelog()

    def mapPriority(self, levelName):
        """
        Map a logging level name to a key in the priority_names map.
        This is useful in two scenarios: when custom levels are being
        used, and in the case where you can't do a straightforward
        mapping by lowercasing the logging level name because of locale-
        specific issues (see SF #1524081).
        """
        return self.priority_map.get(levelName, "warning")

    def emit(self, record):
        """
        Emit a record.

        The record is formatted, and then sent to syslog.
        """
        msg = self.format(record)
        priority = self.priority_names[self.mapPriority(record.levelname)]
        syslog.syslog(priority, msg)

class EmailReportHandler(logging.Handler):
    """
    A handler class which sends an email report when it is closed or flushed.
    """

    def __init__(self, mail_from, mail_to, mail_subject, smtp_host):
        logging.Handler.__init__(self)
        self.mail_from = mail_from
        self.mail_to = mail_to
        self.mail_subject = mail_subject
        self.smtp_host = smtp_host
        self.mail_body = ''

        self.test_smtp()

    def test_smtp(self):
        try:
            server = smtplib.SMTP(self.smtp_host)
            if not (200 <= server.ehlo()[0] <= 299):
                (code,resp) = server.helo()
                if not (200 <= code <= 299):
                    raise smtplib.SMTPHeloError(code, resp)
            (code,resp) = server.mail(self.mail_from)
            if code != 250:
                raise smtplib.SMTPSenderRefused(code, resp, self.mail_from)
            (code, resp) = server.rcpt(self.mail_to)
            if code not in (250, 251):
                raise smtplib.SMTPRecipientsRefused({ self.mail_to: (code, resp)})
            server.quit()
        except socket.gaierror, e:
            code, resp = e
            raise ReportingError(resp)
        except smtplib.SMTPHeloError, e:
            code, resp = e
            raise ReportingError('Received %d response from SMTP server: %s' % (code, resp))
        except smtplib.SMTPSenderRefused, e:
            code, resp, sender = e
            raise ReportingError('Received %d response from SMTP server: %s' % (code, resp))
        except smtplib.SMTPRecipientsRefused, e:
            code, resp = e.recipients[self.mail_to]
            raise ReportingError('Received %d response from SMTP server: %s' % (code, resp))
        except Exception, e:
            raise ReportingError(str(e))

    def emit(self, record):
        """
        Emit a record.

        The record is formatted and appended to the message body.
        """
        self.mail_body += self.format(record)+'\n'

    def flush(self):
        if len(self.mail_body):
            # Add the From: and To: headers at the start!
            msg = ("From: %s\r\nTo: %s\r\nSubject: %s\r\n\r\n%s"
                   % (self.mail_from, self.mail_to, self.mail_subject, self.mail_body))

            try:
                server = smtplib.SMTP(self.smtp_host)
                server.sendmail(self.mail_from, [self.mail_to], msg)
                server.quit()
            except smtplib.SMTPException, e:
                sys.stderr.write('Unable to send email report: %s' % e)
            self.mail_body = ''

console_formatter = logging.Formatter('%(levelname)s: %(message)s')

log_handlers = {}

# create two loggers, one logs to all locations,
# and the other logs only to console
logger = logging.getLogger('zonetool')
logger.setLevel(logging.INFO)
logger.addHandler(NullHandler())
console_logger = logging.getLogger('zonetool-console')
console_logger.setLevel(logging.INFO)
console_logger.addHandler(NullHandler())

def enable_console_logging():
    log_handlers['console'] = logging.StreamHandler()
    log_handlers['console'].setLevel(logging.DEBUG)
    log_handlers['console'].setFormatter(console_formatter)
    logger.addHandler(log_handlers['console'])
    console_logger.addHandler(log_handlers['console'])

def enable_syslog():
    log_handlers['syslog'] = LocalSysLogHandler('zonetool', syslog.LOG_PID, settings.values['reporting']['syslog_facility'])
    log_handlers['syslog'].setLevel(logging.INFO)
    logger.addHandler(log_handlers['syslog'])

def enable_debug_logging():
    logger.setLevel(logging.DEBUG)
    console_logger.setLevel(logging.DEBUG)

def enable_email_logging():
    log_handlers['email'] = EmailReportHandler(settings.values['reporting']['mail_from'],
            settings.values['reporting']['mail_to'], settings.values['reporting']['mail_subject'],
            settings.values['reporting']['smtp_host'])
    log_handlers['email'].setLevel(logging.DEBUG)
    log_handlers['email'].setFormatter(console_formatter)

    logger.addHandler(log_handlers['email'])
    console_logger.addHandler(log_handlers['email'])

def flush_handler(name):
    if log_handlers.has_key(name):
        log_handlers[name].flush()

def set_handler_log_level(name, severity=logging.DEBUG):
    if log_handlers.has_key(name):
        log_handlers[name].setLevel(severity)

def disable_handler(name):
    if log_handlers.has_key(name):
        logger.removeHandler(log_handlers[name])
        console_logger.removeHandler(log_handlers[name])
        del log_handlers[name]
