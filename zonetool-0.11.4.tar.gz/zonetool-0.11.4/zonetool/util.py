#    Zonetool is a utility for signing and maintaining DNSSEC zones and keys.
#
#    Copyright (2009) Sandia Corporation. Under the terms of Contract
#    DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
#    certain rights in this software.
#
#    This package is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This package is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License along
#    with this program; if not, write to the Free Software Foundation, Inc.,
#    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

import datetime
import errno
import fcntl
import os
import re
import resource
import signal
import subprocess
import struct
import sys
import time

from errors import ZoneToolError
from log import logger, console_logger

_maj_min_patch_release_re = re.compile(r'^(?P<vers>\d+)\.(?P<major>\d+)(\.(?P<minor>\d+))?(-P(?P<patch>\d+))?$')
_maj_min_esv_release_re = re.compile(r'^(?P<vers>\d+)\.(?P<major>\d+)-ESV(-R(?P<minor>\d+))?(-P(?P<patch>\d+))?$')

serial_re = re.compile(r'loaded\s+serial\s+(\d+)')

yyyymmdd_serial_re = re.compile(r'(?P<date>\d\d\d\d\d\d\d\d)(?P<iter>\d\d)')
SERIAL_REVERSE_WINDOW = datetime.timedelta(90)
SERIAL_FORWARD_WINDOW = datetime.timedelta(1)

class CommandError(ZoneToolError):
    pass

class SerialUpdateError(ZoneToolError):
    pass

class SerialDetectionError(ZoneToolError):
    pass

_tool_versions = {}

def check_named_conf(named_conf, chroot='', checkconf_args=[]):
    '''Check syntax of a BIND named configuration file.'''

    checkconf_args = checkconf_args[:]

    # if using a chrooted environment, add the -t switch
    if chroot:
        checkconf_args += ['-t', chroot]

    # check a named.conf file for syntax
    cmd = ['named-checkconf'] + checkconf_args + [named_conf]
    console_logger.debug(' '.join(cmd))
    try:
        checkconf = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, close_fds=True)
    except OSError, e:
        raise CommandError(str(e))
    if checkconf.wait() != 0:
        raise CommandError(checkconf.stdout.read())

def dig_query(name, rrtype, server=None, port=None, dig_args=[]):
    '''Issue a query to a name server using dig.'''

    dig_args = dig_args[:]

    cmd = ['dig']
    if port is not None:
        cmd += ['-p', str(port)]
    if server is not None:
        cmd.append('@'+server)
    cmd += dig_args + [name, rrtype]
    console_logger.debug(' '.join(cmd))
    try:
        dig = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, close_fds=True)
    except OSError, e:
        raise CommandError(str(e))
    if dig.wait() != 0:
        raise CommandError(dig.stdout.read())

    return dig.stdout.read()

def check_zone(origin, zone_file, chroot='', checkzone_args=[]):
    '''Check syntax of a zone file.'''

    checkzone_args = checkzone_args[:]

    # if using a chrooted environment, add the -t switch
    if chroot:
        checkzone_args += ['-t', chroot]

    # check the zone file for syntax
    cmd = ['named-checkzone'] + checkzone_args + [origin, zone_file]
    console_logger.debug(' '.join(cmd))
    try:
        checkzone = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, close_fds=True)
    except OSError, e:
        raise CommandError(str(e))
    if checkzone.wait() != 0:
        raise CommandError(checkzone.stdout.read())

def tool_version(tool, *args):
    if _tool_versions.has_key(tool):
        return _tool_versions[tool]
    # find out what version of checkzone we are using
    _tool_versions[tool] = {}
    cmd = [tool] + list(args)
    try:
        console_logger.debug(' '.join(cmd))
        checkzone = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, close_fds=True)
    except OSError, e:
        raise CommandError(str(e))
    full_vers = checkzone.stdout.read().strip()
    match = _maj_min_patch_release_re.match(full_vers)
    _tool_versions[tool]['esv'] = False
    if match is None:
        match = _maj_min_esv_release_re.match(full_vers)
        if match is not None:
            _tool_versions[tool]['esv'] = True

    if match is None:
        logger.warn('Unable to parse %s version from "%s"' % (tool, full_vers))
        _tool_versions[tool]['vers'] = 9
        _tool_versions[tool]['major'] = 2
        _tool_versions[tool]['minor'] = None
        _tool_versions[tool]['patch'] = None
    else:
        _tool_versions[tool]['vers'] = match.group('vers')
        _tool_versions[tool]['major'] = match.group('major')
        _tool_versions[tool]['minor'] = match.group('minor')
        _tool_versions[tool]['patch'] = match.group('patch')

    return _tool_versions[tool]

def check_zone_disable_checking_args():
    # find out what version of checkzone we are using
    version = tool_version('named-checkzone','-v')

    checkzone_args = []
    try:
        vers = int(version['vers'])
        major = int(version['major'])
    except ValueError:
        return checkzone_args

    # disable all checks, according to version
    if vers >= 9 and major >= 3:
        checkzone_args += [
            '-k','ignore',
            '-n','ignore',
        ]
    if vers >= 9 and major >= 4:
        #XXX ???
        pass
    if vers >= 9 and major >= 5:
        checkzone_args += [
            '-i','none',
            '-m','ignore',
            '-M','ignore',
            '-S','ignore',
            '-W','ignore',
        ]

    return checkzone_args

def serial_for_zone(origin, zone_file, chroot=''):
    '''Use named-checkzone to extract the serial from a zone file.'''

    checkzone_args = check_zone_disable_checking_args()

    # if using a chrooted environment, at the -t switch
    if chroot:
        checkzone_args += ['-t', chroot]

    # check the current zone file for syntax, and canonicalize it
    cmd = ['named-checkzone'] + checkzone_args + [origin, zone_file]
    console_logger.debug(' '.join(cmd))
    try:
        checkzone = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, close_fds=True)
    except OSError, e:
        raise CommandError(str(e))
    if checkzone.wait() != 0:
        raise CommandError(checkzone.stdout.read())
    output = checkzone.stdout.read()
    m = serial_re.search(output)
    try:
        if m is None:
            raise ValueError
        return int(m.group(1))
    except ValueError:
        raise CommandError('Unable to determine serial of %s/IN in %s: %s' % (origin, zone_file, output))

def run_rndc(subcommand, origin=None, view=None):
    '''Run rndc with the given command.'''

    cmd = ['rndc', subcommand]

    if origin is not None:
        cmd += [origin]
        if view is not None:
            cmd += ['IN', view]

    console_logger.debug(' '.join(cmd))
    try:
        rndc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, close_fds=True)
    except OSError, e:
        raise CommandError(str(e))
    if rndc.wait() != 0:
        raise CommandError(rndc.stdout.read())

def rndc_freeze(origin, view=None):
    '''Freeze a dynamic zone using rndc.'''

    try:
        run_rndc('freeze', origin, view)
    # if recently issued a thaw, which is handled asynchronously,
    # it may not be instantly ready to freeze again
    except CommandError:
        time.sleep(3)
        run_rndc('freeze', origin, view)

def rndc_thaw(origin, view=None):
    '''Thaw a dynamic zone using rndc.'''

    run_rndc('thaw', origin, view)

def rndc_reload_conf():
    '''Reload the named configuration using rndc.'''

    run_rndc('reload')

def rndc_reload_zone(origin, view=None):
    '''Reload a zone using rndc.'''

    run_rndc('reload', origin, view)

def selinux_enabled():
    '''Return True if SELinux is enabled, False otherwise.'''

    cmd = ['selinuxenabled']

    try:
        return subprocess.call(cmd) == 0
    except OSError, e:
        return False

def selinux_restorecon(path, restorecon_args=[]):
    '''Restore SELinux context on the given path.'''

    restorecon_args = restorecon_args[:]

    cmd = ['restorecon'] + restorecon_args + [path]

    console_logger.debug(' '.join(cmd))
    try:
        restorecon = subprocess.Popen(cmd, close_fds=True)
    except OSError, e:
        raise CommandError(str(e))
    if restorecon.wait() != 0:
        raise CommandError(restorecon.stdout.read())

def parent(name):
    '''Return the parent name of the name supplied.'''

    parts = name.strip('.').split('.')
    return '.'.join(parts[1:])+'.'

def chroot_relative_path(path, chroot):
    '''Strip the chroot path from the path and return the resulting relative path.'''

    return path.replace(chroot.rstrip(os.sep), '', 1)

def ensure_dir_exists(path, perms=0755):
    stack = []
    head = None
    while not os.path.exists(path):
        head, tail = os.path.split(path)
        if head == path:
            break
        stack.append(tail)
        path = head

    while stack:
        path = os.path.join(path, stack.pop())
        os.mkdir(path, perms)

def increment_serial_yyyymmdd(serial):
    match = yyyymmdd_serial_re.match(str(serial))
    if match is None:
        raise SerialDetectionError
    try:
        now = datetime.date.today()
        date = datetime.date(*(time.strptime(match.group('date'), '%Y%m%d')[0:3]))
        change = (now + SERIAL_FORWARD_WINDOW) - date
        if change > datetime.timedelta(0) and change < SERIAL_REVERSE_WINDOW:
            if now > date:
                date = now
                iter = 0
            else:
                iter = int(match.group('iter')) + 1
                if iter > 99:
                    raise SerialUpdateError('Maximum serial reached for %d' % serial)
            return int('%s%02' % (date.strftime('%Y%m%d'), iter))
    except ValueError:
        pass

    raise SerialDetectionError

def increment_serial_unix(serial):
    try:
        now = datetime.datetime.now()
        date = datetime.datetime(*(time.localtime(serial)[0:6]))
        change = (now + SERIAL_FORWARD_WINDOW) - date
        if change > datetime.timedelta(0) and change < SERIAL_REVERSE_WINDOW:
            if now > date:
                date = now
            else:
                date += datetime.timedelta(seconds=1)
            return int(time.mktime(date.timetuple()))
    except ValueError:
        pass
    raise SerialDetectionError

def increment_serial(serial):
    try:
        return increment_serial_yyyymmdd(serial)
    except SerialDetectionError:
        pass
    #try:
    #    return increment_serial_unix(serial)
    #except SerialDetectionError:
    #    pass
    return serial + 1

def zone_str(origin, cls, view):
    if origin != '.':
        origin = origin.rstrip('.')
    if view is None:
        return '%s/%s' % (origin, cls)
    else:
        return '%s/%s/%s' % (origin, cls, view)

def _lock_handoff_child(parent_fh, fd_range=None):
    if fd_range is None:
        maxfd = resource.getrlimit(resource.RLIMIT_NOFILE)[1]
        if (maxfd == resource.RLIM_INFINITY):
            maxfd = 1024
        fd_range = range(0, maxfd)

    def _lock_timeout(sig, frm):
        raise IOError

    signal.signal(signal.SIGALRM, _lock_timeout)
  
    # Iterate through and request the lock on all locked file descriptors.
    for fd in fd_range:
        try:
            fcntl.lockf(fd, fcntl.LOCK_EX|fcntl.LOCK_NB)
            # if we obtained the lock without requesting it, then
            # either the parent has died prematurely, or it didn't
            # have the fd locked to begin with.  If the parent is
            # still alive, then it didn't have a lock, so we release
            # the lock we obtained, so we don't use up system
            # resources; otherwise, we retain it because we don't
            # know whether or not it was locked to begin with.
            if os.getppid() != 1:
                fcntl.lockf(fd, fcntl.LOCK_UN)
        except IOError, e:
            # if not related to blocking (e.g., if the fd was
            # not open), then move along
            if e.errno not in (errno.EACCES, errno.EAGAIN):
                continue
            # notify the parent to release the lock
            try:
                parent_fh.write(struct.pack('l',fd))
                parent_fh.flush()
            except IOError, e:
                raise ZoneToolError("Cannot communicate with parent to release lock on fd %d: %s\n" % (fd, e))
            try:
                signal.alarm(5)
                fcntl.lockf(fd, fcntl.LOCK_EX)
                signal.alarm(0)
            except IOError, e:
                raise ZoneToolError("Lost lock on fd %d when backgrounding: %s\n" % (fd, e))
        
def _lock_handoff_parent(child_fh):
    msgsize = struct.calcsize('l')
    val = child_fh.read(msgsize)
    while val != '':
        locked_fd, = struct.unpack('l', val)
        fcntl.lockf(locked_fd, fcntl.LOCK_UN)
        val = child_fh.read(msgsize)

def daemonize():
    ''' Fork the current process as a daemon, redirecting standard file
        descriptors to /dev/null.
    '''
    # Perform first fork.
    try:
        fd_r, fd_w = os.pipe()
        pid = os.fork()
    except OSError, e:
        raise ZoneToolError("fork #1 failed while daemonizing: (%d) %s\n" % (e.errno, e.strerror))

    if pid > 0:
        try:
            os.close(fd_w)
            _lock_handoff_parent(os.fdopen(fd_r, 'rb'))
        except:
            logger.exception('File lock handoff failed while daemonizing')
            os._exit(1)
        os._exit(0) # Exit first parent.
    os.close(fd_r)
    _lock_handoff_child(os.fdopen(fd_w, 'wb'))

    # Decouple from parent environment.
    os.chdir("/")
    os.umask(0)
    os.setsid()

    # Perform second fork.
    try:
        fd_r, fd_w = os.pipe()
        pid = os.fork()
    except OSError, e:
        raise ZoneToolError("fork #2 failed while daemonizing: (%d) %s\n" % (e.errno, e.strerror))
    if pid > 0:
        try:
            os.close(fd_w)
            _lock_handoff_parent(os.fdopen(fd_r, 'rb'))
        except:
            logger.exception('File lock handoff failed while daemonizing')
            os._exit(1)
        os._exit(0) # Exit second parent.
    os.close(fd_r)
    _lock_handoff_child(os.fdopen(fd_w, 'wb'))

    # The process is now daemonized, redirect standard file descriptors.
    for f in sys.stdout, sys.stderr: f.flush()
    si = file('/dev/null', 'r')
    so = file('/dev/null', 'a+')
    se = file('/dev/null', 'a+', 0)
    os.dup2(si.fileno(), sys.stdin.fileno())
    os.dup2(so.fileno(), sys.stdout.fileno())
    os.dup2(se.fileno(), sys.stderr.fileno())

def seek_line_start(fh):
    '''Position the file at the beginning of the current line.'''

    # get the current point in the file
    i = fh.tell()

    # first get past any newlines at the current point in the file
    while i > 0 and fh.read(1) in '\r\n':
        i -= 1
        fh.seek(i, 0)

    # now find the beginning of the current line
    fh.seek(i, 0)
    while i > 0 and fh.read(1) not in '\r\n':
        i -= 1
        fh.seek(i, 0)
