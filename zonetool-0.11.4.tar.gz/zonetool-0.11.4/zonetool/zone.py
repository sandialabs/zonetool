#    Zonetool is a utility for signing and maintaining DNSSEC zones and keys.
#
#    Copyright (2009) Sandia Corporation. Under the terms of Contract
#    DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
#    certain rights in this software.
#
#    This package is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This package is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License along
#    with this program; if not, write to the Free Software Foundation, Inc.,
#    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

import base64
import calendar
import errno
import fcntl
import os
import random
import re
import shutil
import signal
import stat
import struct
import sys
import tempfile
import time

try:
    import hashlib
    md5_hash_func = hashlib.md5
except ImportError:
    import md5
    md5_hash_func = md5.new

from dnssec_util import DNSKEY_SUFFIXES, DNSKEY_FLAGS, DNSKEY_PROTOCOLS, \
        NSEC3_FLAGS, DNSSEC_NONKEY_RRTYPES, DNSSEC_KEY_RRTYPES, \
        canonicalize_name, canonicalize_zone, sign_zone, strip_key_suffix, ds_ttl
from errors import ZoneToolError
from progressBar import progressBar
import settings
from util import CommandError, dig_query, rndc_freeze, rndc_thaw, rndc_reload_zone, \
        serial_for_zone, chroot_relative_path, \
        check_zone_disable_checking_args, check_zone, ensure_dir_exists, \
        selinux_restorecon, selinux_enabled, increment_serial, zone_str, \
        seek_line_start
from log import logger, console_logger, flush_handler

DEFAULT_VIEW = '_default'

WHITESPACE_RE = re.compile(r'\s+')
ZONE_COMMENT_RE = re.compile(r'\s*;.*')

class StateTransitionError(ZoneToolError):
    pass

class InvalidTransition(StateTransitionError):
    pass

class InconsistentKeys(StateTransitionError):
    pass

class InconsistentSerial(StateTransitionError):
    pass

class StateNotExpired(StateTransitionError):
    pass

class LogError(ZoneToolError):
    pass

class LogDoesNotExist(LogError):
    pass

class LogWriteError(LogError):
    pass

class LogReadError(LogError):
    pass

class LogLockError(LogError):
    pass

class ZoneError(ZoneToolError):
    pass

class UnknownAlgorithm(ZoneError):
    pass

class KeyTagCollision(ZoneError):
    pass

class KeyImportError(ZoneError):
    pass

class DNSSECKeyError(ZoneToolError):
    pass

class DNSSECKey(object):
    def __init__(self, name, flags, protocol, algorithm, key=None, ttl=None, key_tag=None):
        assert (key is not None and key_tag is None) or \
                (key is None and key_tag is not None), "Exactly one of key or key_tag must be provided"

        self.name = name
        self.flags = flags
        self.protocol = protocol
        self.algorithm = algorithm
        self.ttl = ttl

        if key is None:
            self.key = None
        else:
            self.key = WHITESPACE_RE.sub('', key)

        self._key_tag = key_tag

        self.file_mtime = None
        self.file = None

    def __cmp__(self, other):
        '''Compare the fields of each DNSSECKey instance.'''

        if (self.name, self.protocol, self.algorithm, self.key_tag()) != \
                (other.name, other.protocol, other.algorithm, other.key_tag()):
            return 1
        if self.flags is not None and other.flags is not None and \
                self.flags != other.flags:
            return 1
        if self.key is not None and other.key is not None and \
                self.key != other.key:
            return 1
        return 0

    def __str__(self):
        return self.filename()

    def key_len(self):
        '''Return the length of the key in bits.'''

        assert self.key is not None, "key_len() requires that the key value is known"

        key_str = base64.b64decode(self.key)
        # RSA keys
        if self.algorithm in (1,5,7,8,10):
            # get the exponent length
            e_len, = struct.unpack('B',key_str[0])
            offset = 1
            if e_len == 0:
                e_len, = struct.unpack('!H',key_str[1:3])
                offset = 3

            # get the exponent 
            offset += e_len

            # get the modulus
            return (len(key_str) - offset) << 3

        # DSA keys
        elif self.algorithm in (3,6):
            t, = struct.unpack('B',key_str[0])
            return (64 + t*8)<<3

        raise UnknownAlgorithm('Zonetool is unable to determine key type and size for algorithm %d' % self.algorithm)

    def rr(self):
        assert self.flags is not None and self.key is not None, "rr() requires that flags and key values are known"

        if self.ttl is None:
            ttl = ''
        else:
            ttl = self.ttl

        key_parts = ['('] + re.findall(r'(.{1,36})', self.key) + [')']
        key = '%s ; key id = %d' % ('\n\t\t\t\t\t'.join(key_parts), self.key_tag())

        return '%s %s %s %s %d %d %d %s' % \
            (self.name, ttl, 'IN', 'DNSKEY', self.flags, self.protocol, self.algorithm, key)

    def key_tag(self):
        '''Return the key_tag for the given key, flags, protocol, algorithm,
        as specified in RFC 4034.'''

        if self.flags is None or self.key is None:
            assert self._key_tag is not None, "key_tag() requires that _key_tag is set if flags and key values are not known."
            return self._key_tag

        key_str = struct.pack('!HBB', self.flags, self.protocol, self.algorithm) + base64.b64decode(self.key)

        # handle RSAMD5 properly
        if self.algorithm == 1:
            key_tag, = struct.unpack('!H', key_str[-3:-1])
            return key_tag

        ac = 0
        for i in range(len(key_str)):
            b, = struct.unpack('B',key_str[i])
            if i & 1:
                ac += b
            else:
                ac += (b << 8)

        ac += (ac >> 16) & 0xffff
        return ac & 0xffff

    def filename(self):
        '''Return the basename of the corresponding key file.'''

        return 'K%s+%03d+%05d' % (self.name, self.algorithm, self.key_tag())

    def find_file_info(self, key_dirs):
        for d in key_dirs:
            # attempt to check existence of both the
            # public and private key files
            key_file = os.path.join(d, self.filename())
            exists = True
            for ext in DNSKEY_SUFFIXES:
                if not os.path.exists(key_file+ext):
                    exists = False
            if not exists:
                continue

            key_obj = DNSSECKey.from_file(key_file)

            # if the values match, then assign file information
            if self == key_obj:
                # if the key/flags values were missing, then
                # update them, and remove _key_tag
                if self.key is None:
                    self.key = key_obj.key
                if self.flags is None:
                    self.flags = key_obj.flags
                self._key_tag = None

                self.file = key_file
                self.file_mtime = time.localtime(os.path.getmtime(key_file+'.key'))
                break

    def remove_files(self):
        '''Remove files associated with this key.'''

        if self.file is None:
            return
        key_removal_errors = ''
        for ext in DNSKEY_SUFFIXES:
            try:
                os.remove(self.file+ext)
            except OSError, e:
                key_removal_errors += 'Unable to remove file %s for key %s: %s\n' % (self.file+ext, self, e)
        if key_removal_errors:
            raise ZoneError(key_removal_errors)

    @classmethod
    def from_file(cls, key_file):
        key_file = strip_key_suffix(key_file)+'.key'
        try:
            for line in open(key_file):
                line = line.rstrip()
                line = ZONE_COMMENT_RE.sub('', line)
                if line:
                    break

            if not line:
                raise ValueError('no data found in public key file!')

            (name, cls, rrtype, flags, protocol, algorithm, key) = line.split(None, 6)

            name = canonicalize_name(name)
            flags = int(flags)
            protocol = int(protocol)
            algorithm = int(algorithm)

            # canonicalize by removing comments and whitespace
            key = ZONE_COMMENT_RE.sub('', key)
            key = WHITESPACE_RE.sub('', key)

            key = DNSSECKey(name, flags, protocol, algorithm, key)

            key.file = strip_key_suffix(key_file)
            key.file_mtime = time.localtime(os.path.getmtime(key_file))

            return key

        except (IOError, ValueError), e:
            raise DNSSECKeyError('Could not create DNSSECKey object from %s:\n%s' % (key_file, e))

class Zone(object):
    def __init__(self, origin, cls, view, zone_file, key_directory, is_dynamic, meta_directory, chroot='', dnskey_ttl='', nsec3param_ttl=''):
        self.origin = canonicalize_name(origin)
        self.cls = cls.upper()
        self.view = view
        self.zone_file = zone_file
        self.key_directory = key_directory
        self.is_dynamic = is_dynamic
        self.meta_directory = meta_directory
        self.chroot = chroot
        self.dnskey_ttl = dnskey_ttl
        self.nsec3param_ttl = nsec3param_ttl

        self.zone_file_md5 = None
        self.zone_file_canonical = None

        if not (self.zone_file is not None and 
                os.path.exists(self.zone_file) and os.access(self.zone_file, os.R_OK)):
            raise ZoneError('Zone file %s for %s does not exist or is not readable.' % (self.zone_file, self))
        self.refresh_zone_info()

        if self.key_directory is not None and \
                not (os.path.exists(self.key_directory) and os.access(self.key_directory, os.R_OK|os.X_OK)):
            raise ZoneError('Key directory %s for %s does not exist or is not readable.' % (self.key_directory, self))
        self._get_unsigned_zone_file()

    def __str__(self):
        return zone_str(self.origin, self.cls, self.view)

    def __del__(self):
        import os
        # clean up tmp file
        if self.zone_file_canonical is not None:
            os.remove(self.zone_file_canonical)

    def chroot_relative(self, path):
        return chroot_relative_path(path, self.chroot)

    def _reset_zone_info(self):
        '''Initialize all instance variable values to None.'''

        self.min_expire_rr = None
        self.min_expire_dt = None
        self.max_expire_rr = None
        self.max_expire_dt = None
        self.max_ttl_name = None
        self.max_ttl_rrtype = None
        self.max_ttl = None
        self.max_key_ttl = None

        self.serial = None

        self.nsec3 = False
        self.nsec3_salt = None
        self.nsec3_salt_varies = False
        self.nsec3_iter = None
        self.nsec3_iter_varies = False
        self.nsec3_optout = False

        self.active_ksks = []
        self.published_ksks = []
        self.unpublished_ksks = []
        self.active_zsks = []
        self.published_zsks = []
        self.unpublished_zsks = []

        self.signed_active_ksks = []
        self.signed_published_ksks = []
        self.signed_unpublished_ksks = []
        self.signed_active_zsks = []
        self.signed_published_zsks = []
        self.signed_unpublished_zsks = []

        self.is_signed = False

        self.warnings = []

    def signed_zone_file(self):
        if self.is_signed:
            return self.zone_file
        else:
            return self.zone_file.rstrip('.')+'.signed'

    def _get_unsigned_zone_file(self):
        self.unsigned_zone_file = None
        self.unsigned_serial = None

        # if the zone is signed, then try to determine the path of the unsigned version
        # of the zone file, and find the serial in the unsigned zone file
        if self.is_signed:
            if self.is_dynamic:
                return
            if not self.zone_file.endswith('.signed'):
                return
            # strip the .signed from the end
            unsigned_zone_file = self.zone_file[:-7]
            if not os.path.exists(unsigned_zone_file):
                # if that file doesn't exist, try adding a period
                unsigned_zone_file = self.zone_file + '.'
                if not os.path.exists(unsigned_zone_file):
                    return
            self.unsigned_zone_file = unsigned_zone_file
            try:
                self.unsigned_serial = serial_for_zone(self.origin, self.chroot_relative(self.unsigned_zone_file), self.chroot)
            except CommandError, e:
                logger.warn('Unable to obtain unsigned serial for %s: %s' % (self, e))
        else:
            self.unsigned_zone_file = self.zone_file

    def to_state(self, state, expire, start=None):
        '''Return a ZoneState instance corresponding to this zone, with
        the given state and expiration.'''

        active_zsks = [key.filename() for key in self.active_zsks]
        published_zsks = [key.filename() for key in self.published_zsks]
        unpublished_zsks = [key.filename() for key in self.unpublished_zsks]
        active_ksks = [key.filename() for key in self.active_ksks]
        published_ksks = [key.filename() for key in self.published_ksks]
        unpublished_ksks = [key.filename() for key in self.unpublished_ksks]

        if start is None:
            start = time.localtime()

        return ZoneState(state, start, expire, self.serial, self.unsigned_serial,
                active_zsks, published_zsks, unpublished_zsks,
                active_ksks, published_ksks, unpublished_ksks)

    def refresh_zone_info(self, included_ksks=[]):
        f = open(self.zone_file, 'rb')
        new_md5 = md5_hash_func(f.read()).digest()

        # if the file has changed since we last read it and 
        # got the canonical version, re-read
        if new_md5 != self.zone_file_md5:
            self.zone_file_md5 = new_md5
            if self.zone_file_canonical is not None:
                os.remove(self.zone_file_canonical)

            self._reset_zone_info()
            self._get_zone_info()

            self.remove_published_ksks(included_ksks)

    def remove_published_ksks(self, keys):
        for key in self.active_ksks:
            if key in keys:
                self.active_ksks.remove(key)

    def _check_key_directory(self):
        if not self.is_dynamic:
            return

        if self.key_directory is None:
            raise ZoneError('No key directory specified for dynamic zone %s' % (self))

        for key in self.active_zsks:
            for ext in DNSKEY_SUFFIXES:
                key_file = os.path.join(self.key_directory, key.filename()+ext)
                if not (os.path.exists(key_file) and key == DNSSECKey.from_file(key_file)):
                    raise ZoneError('Active ZSK file %s not found in key directory %s' % (key_file, self.key_directory))
        for key in self.unpublished_zsks:
            for ext in DNSKEY_SUFFIXES:
                key_file = os.path.join(self.key_directory, key.filename()+ext)
                if not (os.path.exists(key_file) and key == DNSSECKey.from_file(key_file)):
                    raise ZoneError('Unpublished ZSK file %s not found in key directory %s' % (key_file, self.key_directory))
        for key in self.published_zsks:
            for ext in DNSKEY_SUFFIXES:
                key_file = os.path.join(self.key_directory, key.filename()+ext)
                if os.path.exists(key_file) and key == DNSSECKey.from_file(key_file):
                    raise ZoneError('Published ZSK file %s found in key directory %s' % (key_file, self.key_directory))

    def _check_key_files(self):
        orphaned_keys = filter(lambda x: x.file is None,
                self.active_zsks + self.published_ksks + self.unpublished_zsks + 
                self.active_ksks + self.published_zsks + self.unpublished_ksks)
        if orphaned_keys:
            raise ZoneError('No valid key file pairs found for %s' % (', '.join([key.filename() for key in orphaned_keys])))

    def _get_zone_info(self, key_dirs=[]):
        '''Examine the given zone file to extract DNSSEC information.  In particular, examine
        the active and published ZSKs and KSKs, and their algorithms.'''

        key_dirs = key_dirs[:]

        dnskey_rrsig_keys = []
        soa_rrsig_keys = []
        dnskeys = {}

        self.zone_file_canonical = canonicalize_zone(self.origin, self.chroot_relative(self.zone_file), chroot=self.chroot)

        fh = open(self.zone_file_canonical)

        if self.key_directory is not None:
            key_dirs.append(self.key_directory)
        if self.meta_directory is not None:
            key_dirs.append(self.meta_directory)

        # extract pertinent information from the zone file
        for line in fh:
            (name, ttl, cls, rrtype, val) = line.split(None, 4)

            # update max_ttl
            ttl = int(ttl)
            if self.max_ttl is None or ttl > self.max_ttl:
                self.max_ttl = ttl
                self.max_ttl_rrname = name
                self.max_ttl_rrtype = rrtype

            # analyze NSEC3 record
            if rrtype == 'NSEC3':
                (hash_alg, flags, iter, salt, extra) = val.split(None, 4)
                hash_alg = int(hash_alg)
                flags = int(flags)
                iter = int(iter)
                salt = int(salt, 16)

                self.nsec3 = True

                # find out if the opt-out bit is set
                if flags & NSEC3_FLAGS['OPTOUT']:
                    self.nsec3_optout = True

                # if the number of iterations is not set,
                # then set it.  If it differs from what
                # was detected previously, then set nsec3_salt_varies
                if self.nsec3_iter is None:
                    self.nsec3_iter = int(iter)
                elif self.nsec3_iter != iter:
                    self.nsec3_iter_varies = True

                # if the number of iterations is not set,
                # then set it.  If it differs from what
                # was detected previously, then set nsec3_salt_varies
                if self.nsec3_salt is None:
                    self.nsec3_salt = int(salt)
                elif self.nsec3_salt != salt:
                    self.nsec3_salt_varies = True

            elif rrtype == 'RRSIG':
                # get the RRSIG RR fields
                (covered, algorithm, labels, orig_ttl, sig_expiration, sig_inception, key_tag, key_name, sig) = val.split(None, 8)

                # add key_tags for DNSKEY and SOA RRSIGs to
                # lists for later comparison
                if name == self.origin:
                    key_tag = int(key_tag)
                    algorithm = int(algorithm)
                    if covered == 'DNSKEY':
                        dnskey_rrsig_keys.append((key_name,algorithm,key_tag))
                    elif covered == 'SOA':
                        soa_rrsig_keys.append((key_name,algorithm,key_tag))

                    self.is_signed = True

                # obtain the signature expiration in seconds UTC
                utc_expire = calendar.timegm(time.strptime(sig_expiration+'UTC', '%Y%m%d%H%M%S%Z'))
                # convert the expiration to local time
                expire_dt = time.localtime(utc_expire)
                    
                # find the minimum and maximum expiration
                if self.min_expire_dt is None or expire_dt < self.min_expire_dt:
                    self.min_expire_dt = expire_dt
                    self.min_expire_rrname = name
                    self.min_expire_rrtype = covered
                if self.max_expire_dt is None or expire_dt > self.max_expire_dt:
                    self.max_expire_rrname = name
                    self.max_expire_rrtype = covered

            # add DNSSEC keys to the list
            elif rrtype == 'DNSKEY':
                (flags, protocol, algorithm, key) = val.split(None, 3)

                flags = int(flags)
                protocol = int(protocol)
                algorithm = int(algorithm)

                # canonicalize by removing comments
                key = ZONE_COMMENT_RE.sub('', key)

                key_obj = DNSSECKey(self.origin, flags, protocol, algorithm, key, ttl=ttl)
                key_tag = key_obj.key_tag()

                if self.max_key_ttl is None or ttl > self.max_key_ttl:
                    self.max_key_ttl = ttl

                # only investigate this if the DNSSEC protocol is specified
                if protocol == DNSKEY_PROTOCOLS['DNSSEC']:
                    # group keys by key_tag
                    if dnskeys.has_key((name,algorithm,key_tag)):
                        raise KeyTagCollision('Multiple DNSKEYs share an owner name, algorithm, and key tag in %s.' % self)
                    dnskeys[(name,algorithm,key_tag)] = key_obj

            # get the current serial
            elif rrtype == 'SOA' and name == self.origin:
                (mname, rname, serial, refresh, retry, expire, minimum) = val.split(None, 6)
                self.serial = int(serial)

        fh.close()

        # analyze the key_tags used for signing the SOA RR
        for key_name,algorithm,key_tag in soa_rrsig_keys:
            if not dnskeys.has_key((key_name,algorithm,key_tag)):
                key_obj = DNSSECKey(key_name, None, DNSKEY_PROTOCOLS['DNSSEC'], algorithm, key_tag=key_tag)
                key_obj.find_file_info(key_dirs)
                self.unpublished_zsks.append(key_obj)

            # remove all matching keys from those used for signing DNSKEYs
            while True:
                try:
                    dnskey_rrsig_keys.remove((key_name,algorithm,key_tag))
                except ValueError:
                    break

        # analyze the key_tags for signing the DNSKEY RRs
        for key_name,algorithm,key_tag in dnskey_rrsig_keys:
            if not dnskeys.has_key((key_name,algorithm,key_tag)):
                key_obj = DNSSECKey(key_name, None, DNSKEY_PROTOCOLS['DNSSEC'], algorithm, key_tag=key_tag)
                key_obj.find_file_info(key_dirs)
                self.unpublished_ksks.append(key_obj)

        active_ksks = dnskey_rrsig_keys
        active_zsks = soa_rrsig_keys

        # get the keys from the keys directory
        for key_obj in dnskeys.values():
            key_tag = key_obj.key_tag()

            # if this key is an active KSK 
            if (key_obj.name, key_obj.algorithm, key_tag) in active_ksks:
                self.active_ksks.append(key_obj)
                # check that the SEP flag is set
                if not (key_obj.flags & DNSKEY_FLAGS['SEP']):
                    self.warnings.append('%s does not have the SEP flag set' % key_obj.filename())

            # if this key is an active ZSK 
            elif (key_obj.name, key_obj.algorithm, key_tag) in active_zsks:
                self.active_zsks.append(key_obj)

            # if this key is a published KSK 
            elif key_obj.flags & DNSKEY_FLAGS['ZSK'] and key_obj.flags & DNSKEY_FLAGS['SEP']:
                self.published_ksks.append(key_obj)
            
            # if this key is a published ZSK 
            elif key_obj.flags & DNSKEY_FLAGS['ZSK']:
                self.published_zsks.append(key_obj)

            # check that the ZSK flag is set for keys used to sign
            if (key_obj.name, key_obj.algorithm, key_tag) in active_ksks + active_zsks and \
                    not (key_obj.flags & DNSKEY_FLAGS['ZSK']):
                self.warnings.append('%s does not have the ZSK flag set' % key_obj.filename())

            key_obj.find_file_info(key_dirs)

        self.signed_active_zsks = self.active_zsks[:]
        self.signed_published_zsks = self.published_zsks[:]
        self.signed_unpublished_zsks = self.unpublished_zsks[:]
        self.signed_active_ksks = self.active_ksks[:]
        self.signed_published_ksks = self.published_ksks[:]
        self.signed_unpublished_ksks = self.unpublished_ksks[:]

    def _stage_zone(self, new_serial=0, from_unsigned_file=False, strip_dnssec_rrs=True, included_ksks=[]):
        '''Stage a zone file for signing with DNSSEC.  Canonicalize the
        data in the zone file, strip all previous DNSSEC RRs, include
        key files, and check and return the resulting file.'''

        zone_tmp_file = None
        zone_clean_tmp_file = None
        try:
            try:
                # if this zone has not been previously signed, or if from_unsigned_file is True
                # (indicating that the unsigned version has changed), then use the unsigned
                # version of the file to canonicalize
                if not self.is_signed or from_unsigned_file:
                    zone_clean_tmp_file = canonicalize_zone(self.origin, self.chroot_relative(self.unsigned_zone_file), chroot=self.chroot)
                    zone_in_fh = open(zone_clean_tmp_file, 'r')
                else:
                    self.refresh_zone_info(included_ksks)
                    zone_in_fh = open(self.zone_file_canonical, 'r')

                fd, zone_tmp_file = tempfile.mkstemp('', self.origin)
                zone_out_fh = os.fdopen(fd, 'w')

                # write all the RRs to the temporary file
                for line in zone_in_fh:
                    (name, ttl, cls, rrtype, val) = line.split(None, 4)

                    # strip DNSSEC RRs (other than DNSKEY), if specified
                    if strip_dnssec_rrs:
                        if rrtype in DNSSEC_NONKEY_RRTYPES:
                            continue

                    # strip all DNSSEC keys---they will be added later
                    if rrtype in DNSSEC_KEY_RRTYPES:
                        (flags, protocol, algorithm, key) = val.split(None, 3)

                        flags = int(flags)
                        protocol = int(protocol)
                        algorithm = int(algorithm)

                        if protocol == DNSKEY_PROTOCOLS['DNSSEC']:
                            continue

                    # update the serial (unless serial is -1)
                    if rrtype == 'SOA' and new_serial >= 0:
                        (mname, rname, serial, refresh, retry, expire, minimum) = val.split(None, 6)
                        if new_serial == 0:
                            serial = increment_serial(int(serial))
                        else:
                            serial = new_serial
                        line = ' '.join((name, ttl, cls, rrtype, mname, rname, str(serial), refresh, retry, expire, minimum))

                    zone_out_fh.write(line)
                zone_in_fh.close()

                if self.dnskey_ttl:
                    zone_out_fh.write('$TTL %s\n' % self.dnskey_ttl)

                # add the include statements to the intermediate file
                for key in self.active_zsks + self.published_zsks + self.active_ksks + self.published_ksks + included_ksks:
                    zone_out_fh.write('$INCLUDE "%s.key"\n' % key.file)
                # close the file
                zone_out_fh.close()

                # disable checks
                checkzone_args = check_zone_disable_checking_args()

                # check the resulting file
                check_zone(self.origin, zone_tmp_file, checkzone_args=checkzone_args)

                return zone_tmp_file

            # if there were any errors, clean up the temporary file,
            # and re-raise the exception
            except:
                if zone_tmp_file is not None:
                    try:
                        os.remove(zone_tmp_file)
                    except:
                        logger.exception('error removing temporary zone file')
                raise

        finally:
            if zone_clean_tmp_file is not None: os.remove(zone_clean_tmp_file)

    def sign_zone(self, new_serial=0, included_ksks=[], interval=None, nsec3=None, nsec3_salt=None, nsec3_iter=None, nsec3_optout=None, verify_sign=True,
            randomdev=None, prand=False, gen_ds_rrs=False, uid=None, gid=None):
        '''Sign a zone with given KSKs and ZSKs.'''

        if self.is_dynamic and \
                (uid is None or gid is None):
            raise ZoneError('A uid and gid must be specified when signing a dynamic zone')

        if nsec3 is None:
            nsec3 = self.nsec3
        if nsec3_iter is None:
            nsec3_iter = self.nsec3_iter
        if nsec3_optout is None:
            nsec3_optout = self.nsec3_optout

        self._check_key_files()
        self._check_key_directory()

        # compare the keys last used in the zone to those which will be used currently.
        # if there are any differences, then the zone is being "resigned", so strip any
        # DNSSEC-related RRs before signing the zone
        if (set(self.signed_active_zsks) != set(self.active_zsks) or \
                set(self.signed_published_zsks) != set(self.published_zsks) or \
                set(self.signed_unpublished_zsks) != set(self.unpublished_zsks) or \
                set(self.signed_active_ksks) != set(self.active_ksks) or \
                set(self.signed_published_ksks) != set(self.published_ksks) or \
                set(self.signed_unpublished_ksks) != set(self.unpublished_ksks)):
            strip_dnssec_rrs = True
            if nsec3_salt is None:
                nsec3_salt = -1
        else:
            strip_dnssec_rrs = False
            if nsec3_salt is None:
                nsec3_salt = self.nsec3_salt

        # if a positive new serial is specified for a non-dynamic zone, then compare it to the 
        # the serial in the signed version of the zone.  If new serial is greater, then
        # the unsigned version of the zone has changed, so the new version of the zone
        # should be based on the unsigned version, not the signed version.
        if not self.is_signed:
            from_unsigned_file = True
            self.zone_file = self.signed_zone_file()
            if not self.is_dynamic:
                self.unsigned_serial = self.serial
        elif not self.is_dynamic and new_serial > self.serial:
            from_unsigned_file = True
        else:
            from_unsigned_file = False

        zone_tmp_file = None
        signed_zone_tmp_file = None
        try:
            zone_tmp_file = self._stage_zone(new_serial=new_serial, from_unsigned_file=from_unsigned_file,
                    strip_dnssec_rrs=strip_dnssec_rrs, included_ksks=included_ksks)

            fd, signed_zone_tmp_file = tempfile.mkstemp('', self.origin)
            os.close(fd)

            try:
                sign_zone(zone_tmp_file, self.origin, signed_zone_tmp_file,
                        ksk_files=[ksk.file for ksk in self.active_ksks + self.unpublished_ksks + included_ksks],
                        zsk_files=[zsk.file for zsk in self.active_zsks + self.unpublished_zsks],
                        keyset_dir=self.meta_directory, interval=interval, 
                        nsec3=nsec3, nsec3_salt=nsec3_salt, nsec3_iter=nsec3_iter, nsec3_optout=nsec3_optout, verify_sign=verify_sign,
                        randomdev=randomdev, prand=prand, gen_ds_rrs=gen_ds_rrs)

                # if nsec3param_ttl is set, then set it accordingly
                if nsec3 and self.nsec3param_ttl:
                    self.set_nsec3param_ttl(signed_zone_tmp_file)

                # get mode/ownership of previous file
                if os.path.exists(self.zone_file):
                    statinfo = os.stat(self.zone_file)
                else:
                    statinfo = os.stat(self.unsigned_zone_file)

                # move the signed file to its proper location
                console_logger.debug('mv %s %s' % (signed_zone_tmp_file, self.zone_file))
                shutil.move(signed_zone_tmp_file, self.zone_file)

                # restore SELinux context, if applicable
                if os.uname()[0] == 'Linux':
                    try:
                        selinux_restorecon(self.zone_file)
                    except CommandError, e:
                        if selinux_enabled():
                            raise ZoneError('Unable to restore SELinux context of signed zone file %s: %s' % (self.zone_file, e))

                # if zone is dynamic, make it owned by uid/gid, and make sure user can r/w
                if self.is_dynamic:
                    os.chown(self.zone_file, uid, gid)
                    os.chmod(self.zone_file, statinfo[0] | stat.S_IRUSR | stat.S_IWUSR)
                # preserve previous ownership and permission bits on the file
                else:
                    os.chown(self.zone_file, statinfo[4], statinfo[5])
                    os.chmod(self.zone_file, statinfo[0])

            except (CommandError, OSError), e:
                raise ZoneError('Unable to sign %s: %s' % (self, e))

            self.refresh_zone_info(included_ksks)

        finally:
            if zone_tmp_file is not None:
                os.remove(zone_tmp_file)
            if signed_zone_tmp_file is not None and os.path.exists(signed_zone_tmp_file):
                os.remove(signed_zone_tmp_file)

    def import_active_ksk(self, key_obj, move=False):
        self._check_unique_key_names(key_obj)
        self._import_key(key_obj, self.meta_directory, move=move)
        if key_obj not in self.active_ksks:
            self.active_ksks.append(key_obj)

    def import_published_ksk(self, key_obj, move=False):
        self._check_unique_key_names(key_obj)
        self._import_key(key_obj, self.meta_directory, move=move)
        if key_obj not in self.published_ksks:
            self.published_ksks.append(key_obj)

    def import_unpublished_ksk(self, key_obj, move=False):
        self._check_unique_key_names(key_obj)
        self._import_key(key_obj, self.meta_directory, move=move)
        if key_obj not in self.unpublished_ksks:
            self.unpublished_ksks.append(key_obj)

    def import_active_zsk(self, key_obj, move=False, gid=None):
        if self.is_dynamic:
            if gid is None:
                raise KeyImportError('A gid must be specified when importing an active ZSK for a dynamic zone')
            if self.key_directory is None:
                raise KeyImportError('A key-directory must be specified when importing an active ZSK for a dynamic zone')
            key_dir = self.key_directory
        else:
            gid = None
            key_dir = self.meta_directory
        self._check_unique_key_names(key_obj)
        self._import_key(key_obj, key_dir, move=move, gid=gid)
        if key_obj not in self.active_zsks:
            self.active_zsks.append(key_obj)

    def import_published_zsk(self, key_obj, move=False):
        self._check_unique_key_names(key_obj)
        self._import_key(key_obj, self.meta_directory, move=move)
        if key_obj not in self.published_zsks:
            self.published_zsks.append(key_obj)
        
    def import_unpublished_zsk(self, key_obj, move=False, gid=None):
        if self.is_dynamic:
            if gid is None:
                raise KeyImportError('A gid must be specified when importing an unpublished ZSK for a dynamic zone')
            if self.key_directory is None:
                raise KeyImportError('A key-directory must be specified when importing an unpublished ZSK for a dynamic zone')
            key_dir = self.key_directory
        else:
            gid = None
            key_dir = self.meta_directory
        self._check_unique_key_names(key_obj)
        self._import_key(key_obj, key_dir, move=move, gid=gid)
        if key_obj not in self.unpublished_zsks:
            self.unpublished_zsks.append(key_obj)

    def _check_unique_key_names(self, key):
        if key.filename() in [k.filename() for k in \
                self.active_zsks + self.published_zsks + self.unpublished_zsks + \
                self.active_ksks + self.published_ksks + self.unpublished_ksks]:
            raise KeyImportError('Key with matching name "%s" already found among those in use for %s' % (key.filename(), self))

    def _import_key(self, key_obj, key_dir, move=False, gid=None):
        '''Import key_obj.file to the key_dir directory, if it doesn't already
        exist there.'''

        # strip any suffixes from the key files
        src_base = strip_key_suffix(key_obj.file)
        dst_base = os.path.join(key_dir, key_obj.filename())

        # copy existing keys to keys directory
        for ext in DNSKEY_SUFFIXES:
            src = src_base+ext
            dst = dst_base+ext

            # check existence of key file
            if not (os.path.exists(src) and \
                    os.access(src, os.R_OK)):
                raise KeyImportError('Unable to read %s!' % src)

            if os.path.exists(dst):
                # if the key file is already in the directory, no need to import; otherwise
                # avoid a stomping on an existing key with same name, algorithm, and tag
                if not os.path.samefile(src,dst):
                    raise KeyImportError('Unable to import %s for %s: Key with that name already exists in %s!' % (src, self, key_dir))

            else:
                try:
                    if move:
                        console_logger.debug('mv %s %s' % (src,dst))
                        shutil.move(src,dst)
                    else:
                        console_logger.debug('cp %s %s' % (src,dst))
                        shutil.copy2(src,dst)
                except IOError, e:
                    raise KeyImportError('Unable to import %s for %s: %s' % (src, self, e))

                # restore SELinux context, if applicable
                if os.uname()[0] == 'Linux':
                    try:
                        selinux_restorecon(dst)
                    except CommandError, e:
                        if selinux_enabled():
                            raise KeyImportError('Unable to restore SELinux context of DNSSEC key file %s: %s' % (dst, e))

            # set ownership/permissions on private keys
            # if dynamic, let it be owned by group gid, and let group read (0640);
            # otherwise, let only owner read (0600)
            if ext == '.private':
                mode = stat.S_IRUSR | stat.S_IWUSR
                if gid is not None:
                    mode |= stat.S_IRGRP
                try:
                    os.chmod(dst, mode)
                    if gid is not None:
                        statinfo = os.stat(dst)
                        os.chown(dst, statinfo[4], gid)
                except OSError, e:
                    raise KeyImportError('Unable to import %s for %s: %s' % (src, self, e))
            # let public key be read by all (0644)
            else:
                mode = stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IROTH
                try:
                    os.chmod(dst, mode)
                except OSError, e:
                    raise KeyImportError('Unable to import %s for %s: %s' % (src, self, e))

        key_obj.file = dst_base

    def freeze(self, frozen_ok=False):
        if self.is_dynamic:
            try:
                rndc_freeze(self.origin, self.view)
            except CommandError, e:
                if not frozen_ok or str(e).find('already frozen') < 0:
                    raise ZoneError('Unable to freeze %s: %s' % (self, e))

    def thaw(self):
        if self.is_dynamic:
            try:
                rndc_thaw(self.origin, self.view)
            except CommandError, e:
                raise ZoneError('Unable to thaw %s: %s' % (self, e))

    def reload(self):
        try:
            rndc_reload_zone(self.origin, self.view)
        except CommandError, e:
            raise ZoneError('Unable to reload %s: %s' % (self, e))

    def ds_ttl(self, dlv_domain=None):
        try:
            return ds_ttl(self.origin, dlv_domain)
        except CommandError, e:
            raise ZoneError('Unable to detect %s RR TTL for %s: %s' % (dlv_domain and 'DLV' or 'DS', self.origin, e))

    def ds_exists(self, key_obj):
        try:
            rrsig_exists = False
            ds_exists = False

            output = dig_query(self.origin, 'DS', dig_args=['+noall','+answer','+dnssec'])
            if not output:
                return ds_exists, rrsig_exists

            for line in output.split('\n'):
                line = line.rstrip()
                if not line:
                    continue
                (name, ttl, cls, rrtype, val) = line.split(None, 4)
                if name != self.origin:
                    continue
                if rrtype == 'RRSIG':
                    (covered, algorithm, labels, orig_ttl, rest) = val.split(None, 4)
                    if covered == 'DS':
                        rrsig_exists = True
                elif rrtype == 'DS':
                    (key_id, algorithm, rest) = val.split(None, 2)
                    key_id = int(key_id)
                    algorithm = int(algorithm)
                    ds_key_obj = DNSSECKey(name, None, DNSKEY_PROTOCOLS['DNSSEC'], algorithm, key_tag=key_id)
                    if ds_key_obj == key_obj:
                        ds_exists = True
            return ds_exists, rrsig_exists

        except CommandError:
            raise ZoneError('Unable to determine whether DS RR for %s exists: %s' % (self.origin, e))

    def set_nsec3param_ttl(self, zone_file):
        '''Update provided zone file in place by setting the TTL of the
        NSEC3PARAM record to the specified value.'''

        NSEC3PARAM_RE = re.compile(r'^(%s\s|@\s|\s)\s*(\d+\s+)?(IN\s+)?(NSEC3PARAM)' % self.origin.replace('.', '\\.'))
        NSEC3PARAM_RRSIG_RE = re.compile(r'^(%s\s|@\s|\s)\s*(\d+\s+)?(IN\s+)?(RRSIG\s+NSEC3PARAM)' % self.origin.replace('.', '\\.'))

        nsec3param_rr = ''
        nsec3param_rrsig_rr = ''

        fh = open(zone_file, 'r+')
        line = fh.readline()
        while line != '':
            if NSEC3PARAM_RE.match(line):
                nsec3param_rr = NSEC3PARAM_RE.sub(r'%s IN NSEC3PARAM' % self.origin, line)

                # find the beginning of the current line
                # and insert a ';'
                curr = fh.tell()
                fh.seek(curr - 1)
                seek_line_start(fh)
                fh.write(';')
                fh.seek(curr, 0)

            if NSEC3PARAM_RRSIG_RE.match(line):
                nsec3param_rrsig_rr = NSEC3PARAM_RRSIG_RE.sub(r'%s IN RRSIG NSEC3PARAM' % self.origin, line)

                # find the beginning of the current line
                # and insert a ';'
                curr = fh.tell()
                fh.seek(curr - 1, 0)
                seek_line_start(fh)
                fh.write(';')
                fh.seek(curr, 0)

                if '(' in line:
                    while ')' not in line:
                        line = fh.readline()
                        nsec3param_rrsig_rr += line

                        # find the beginning of the current line
                        # and insert a ';'
                        curr = fh.tell()
                        fh.seek(curr - 1, 0)
                        seek_line_start(fh)
                        fh.write(';')
                        fh.seek(curr, 0)

            if nsec3param_rr and nsec3param_rrsig_rr:
                break
            line = fh.readline()

        fh.seek(0, 2)
        fh.write('\n$TTL %s\n' % self.nsec3param_ttl)
        fh.write(nsec3param_rr)
        fh.write(nsec3param_rrsig_rr)

        fh.close()

class ZoneState(object):
    ALLOWED_TRANSITIONS = {
            'signed': ('zsk-pproll-wait-ttl', 'ksk-dsroll-wait-dschange', 'alg-roll-wait-ttl1', 'signed'),
            'zsk-pproll-wait-ttl': ('signed', 'zsk-pproll-wait-ttl'),
            'ksk-dsroll-wait-dschange': ('ksk-dsroll-wait-dsttl', 'ksk-dsroll-wait-dschange'),
            'ksk-dsroll-wait-dsttl': ('signed', 'ksk-dsroll-wait-ttl'),
            'alg-roll-wait-ttl1': ('alg-roll-wait-dschange', 'alg-roll-wait-ttl1'),
            'alg-roll-wait-dschange': ('alg-roll-wait-dsttl', 'alg-roll-wait-dschange'),
            'alg-roll-wait-dsttl': ('alg-roll-wait-ttl2', 'alg-roll-wait-dsttl'),
            'alg-roll-wait-ttl2': ('signed', 'alg-roll-wait-ttl2'),
    }

    def __init__(self, name, start, expire, serial, unsigned_serial,
            active_zsks, published_zsks, unpublished_zsks,
            active_ksks, published_ksks, unpublished_ksks):
        self.name = name
        self.start = start
        self.expire = expire
        self.serial = serial
        self.unsigned_serial = unsigned_serial
        self.active_zsks = active_zsks
        self.published_zsks = published_zsks
        self.unpublished_zsks = unpublished_zsks
        self.active_ksks = active_ksks
        self.published_ksks = published_ksks
        self.unpublished_ksks = unpublished_ksks

    def __str__(self):
        return '%s (%s)' % (self.name, time.strftime('%x %X', self.start))

    def advance(self, zone, next_state, block, serial_must_be_same=True):
        '''Return True if the zone provided can be advanced to the next
        state, provided this is its current state; False otherwise.  This
        check is performed by ensuring that the minimum time in this state
        has elapsed, and any other state-specific issues.  If block is True,
        then this will block until time has elapsed; if it is False, then
        if sufficient time has not passed, it will raise a StateError.  If
        block is None, then the time won't be checked.'''

        # check that the transition is a valid one
        if next_state not in self.ALLOWED_TRANSITIONS.get(self.name, []):
            raise InvalidTransition('Transitioning from "%s" to "%s" is invalid' % (self.name, next_state))

        #XXX custom methods perhaps here
        self.check_keys(zone)
        self.check_serial(zone, serial_must_be_same)

        # if not leaving the current state, no need to check for expiration
        if self.name == next_state:
            return

        # check that sufficient time has passed
        start_secs = time.mktime(time.localtime())
        expire_secs = time.mktime(self.expire)
        if start_secs < expire_secs:
            if block is None:
                # don't bother checking the time
                pass
            elif block:
                # wait until the time has passed
                logger.info('  Sleeping until state "%s" of %s expires at %s' % (self.name, zone, time.strftime('%x %X', self.expire)))
                flush_handler('console')
                show_progress = sys.stdout.isatty() and \
                        settings.values['global'].get('quiet', 'yes').lower() in ('no','false')

                bar = progressBar(0,expire_secs - start_secs)
                now_secs = start_secs
                try:
                    while now_secs < expire_secs:
                        if show_progress:
                            bar(now_secs - start_secs + 1)
                        now_secs = time.mktime(time.localtime())
                        time.sleep(1)
                finally:
                    if show_progress:
                        sys.stdout.write('\n')
            else:
                # raise an error
                raise StateNotExpired('State may not be changed from "%s" until %s.' % (self.name, time.strftime('%x %X', self.expire)))

    def check_serial(self, zone, serial_must_be_same=True):
        if (self.unsigned_serial is None and zone.unsigned_serial is not None) or \
                (self.unsigned_serial is not None and zone.unsigned_serial is None):
            raise InconsistentSerial('Transitioning between dynamic and static zone not supported.')

        if serial_must_be_same and self.unsigned_serial != zone.unsigned_serial:
            raise InconsistentSerial('Modified serial in unsigned version of zone: %s <> %s' % (self.unsigned_serial, zone.unsigned_serial))

    def check_keys(self, zone, check_active_zsks=True, check_published_zsks=True, check_unpublished_zsks=True,
            check_active_ksks=True, check_published_ksks=True, check_unpublished_ksks=True):
        '''Return True if key tags are consistent between the given zone and
        this state.'''

        state = zone.to_state(self.name, self.expire, self.start)

        if check_active_zsks:
            active_zsks = state.active_zsks[:]
            for key in self.active_zsks:
                try:
                    active_zsks.remove(key)
                except ValueError:
                    raise InconsistentKeys('Corrupt state: active ZSK %s not found in zone %s' % (key, zone))
                    
            if active_zsks:
                raise InconsistentKeys('Corrupt state: active ZSK %s found in zone %s' % (active_zsks[0], zone))
        
        if check_published_zsks:
            published_zsks = state.published_zsks[:]
            for key in self.published_zsks:
                try:
                    published_zsks.remove(key)
                except:
                    raise InconsistentKeys('Corrupt state: published ZSK %s not found in zone %s' % (key, zone))
            if published_zsks:
                raise InconsistentKeys('Corrupt state: published ZSK %s found in zone %s' % (published_zsks[0], zone))
        
        if check_unpublished_zsks:
            unpublished_zsks = state.unpublished_zsks[:]
            for key in self.unpublished_zsks:
                try:
                    unpublished_zsks.remove(key)
                except:
                    raise InconsistentKeys('Corrupt state: unpublished ZSK %s not found in zone %s' % (key, zone))
            if unpublished_zsks:
                raise InconsistentKeys('Corrupt state: unpublished ZSK %s found in zone %s' % (unpublished_zsks[0], zone))
        
        if check_active_ksks:
            active_ksks = state.active_ksks[:]
            for key in self.active_ksks:
                try:
                    active_ksks.remove(key)
                except:
                    raise InconsistentKeys('Corrupt state: active KSK %s not found in zone %s' % (key, zone))
            if active_ksks:
                raise InconsistentKeys('Corrupt state: active KSK %s found in zone %s' % (active_ksks[0], zone))

        if check_published_ksks:
            published_ksks = state.published_ksks[:]
            for key in self.published_ksks:
                try:
                    published_ksks.remove(key)
                except:
                    raise InconsistentKeys('Corrupt state: published KSK %s not found in zone %s' % (key, zone))
            for key in published_ksks:
                raise InconsistentKeys('Corrupt state: published KSK %s found in zone %s' % (published_ksks[0], zone))

        if check_unpublished_ksks:
            unpublished_ksks = state.unpublished_ksks[:]
            for key in self.unpublished_ksks:
                try:
                    unpublished_ksks.remove(key)
                except:
                    raise InconsistentKeys('Corrupt state: unpublished KSK %s not found in zone %s' % (key, zone))
            if unpublished_ksks:
                raise InconsistentKeys('Corrupt state: unpublished KSK %s found in zone %s' % (unpublished_ksks[0], zone))

        return True

class ZoneLog(object):
    def __init__(self, log_file):
        self.file = log_file
        self.fh = None

    def initialize_handle(self, write=False, create=False):
        if write:
            if not create and not os.path.exists(self.file):
                raise LogDoesNotExist('Log file %s does not exist!' % self.file)

            try:
                ensure_dir_exists(os.path.dirname(self.file))
                if self.fh is not None:
                    if self.fh.mode[0] == 'a':
                        return
                    else:
                        self.fh.close()

                log_fh = open(self.file, 'a+')

            except (OSError, IOError), e:
                raise LogWriteError('Unable to open zone log file %s for writing: %s' % (self.file, e))

            # attempt to obtain the write lock
            try:
                fcntl.lockf(log_fh, fcntl.LOCK_EX|fcntl.LOCK_NB)
                self.fh = log_fh
            except IOError:
                raise LogLockError('Zone file %s is in use by another process.' % self.file)

        elif self.fh is None:
            try:
                self.fh = open(self.file, 'r')
            except IOError, e:
                if e.errno == errno.ENOENT:
                    raise LogDoesNotExist('Log file %s does not exist!' % self.file)
                raise LogReadError('Unable to open log file for reading: %s' % str(e))

    def __iter__(self):
        return self

    def reset(self):
        '''Reset the file descriptor of the log file to the start of the file.'''

        self.fh.seek(0)

    def next(self, n=1):
        '''Read the values from the current line, parse the values,
        and return an instantiated ZoneState object.'''

        try:
            line = ''
            for i in range(n):
                line = self.fh.readline()
                if line == '':
                    raise StopIteration

            if line == '':
                raise StopIteration
            line = line.rstrip()
            name, start, expire, serial, unsigned_serial, \
                    active_zsks, published_zsks, unpublished_zsks, \
                    active_ksks, published_ksks, unpublished_ksks = line.split('|')

            # obtain the start/expire times in UTC and in local time
            utc_start = calendar.timegm(time.strptime(start+'UTC', '%Y%m%d%H%M%S%Z'))
            utc_expire = calendar.timegm(time.strptime(expire+'UTC', '%Y%m%d%H%M%S%Z'))
            start = time.localtime(utc_start)
            expire = time.localtime(utc_expire)

            serial = int(serial)
            try:
                unsigned_serial = int(unsigned_serial)
            except ValueError:
                unsigned_serial = None
            if active_zsks:
                active_zsks = active_zsks.split(',')
            else:
                active_zsks = []
            if published_zsks:
                published_zsks = published_zsks.split(',')
            else:
                published_zsks = []
            if unpublished_zsks:
                unpublished_zsks = unpublished_zsks.split(',')
            else:
                unpublished_zsks = []
            if active_ksks:
                active_ksks = active_ksks.split(',')
            else:
                active_ksks = []
            if published_ksks:
                published_ksks = published_ksks.split(',')
            else:
                published_ksks = []
            if unpublished_ksks:
                unpublished_ksks = unpublished_ksks.split(',')
            else:
                unpublished_ksks = []

            return ZoneState(name, start, expire, serial, unsigned_serial,
                    active_zsks, published_zsks, unpublished_zsks,
                    active_ksks, published_ksks, unpublished_ksks)

        except (IOError, ValueError):
            raise LogError('Corrupt log entry detected: %s' % line)

    def seek_line_start(self):
        '''Position the file at the beginning of the current line.'''

        seek_line_start(self.fh)

    def previous(self, n=1):
        '''Search for the start of the nth line previous to that which was
        just read.  Instantiate a ZoneState object based on the contents of
        that line.  Note that calling with n=0 will return the state just read.'''

        if self.fh.tell() == 0:
            return None

        # Find out if we're positioned at the beginning of a line.
        # If we are, then we have just read the last line, so to
        # find the nth "previous" line, we need to seek to the whitespace
        # immediately preceding the current position, then call seek_line_start()
        # n+1 times
        curr_char = self.fh.read(1)
        if curr_char != '':
            self.fh.seek(-2,1)
        else:
            self.fh.seek(-1,1)
        prev_char = self.fh.read(1)
        # are we positioned at the start of a new line?
        if curr_char not in '\r\n' and prev_char in '\r\n':
            self.fh.seek(-1,1)

        # get the current point in the file
        i = self.fh.tell()

        for i in range(0,n):
            # seek to the beginning of the current line
            self.seek_line_start()

            # seek into the preceding whitespace, then seek to
            # the beginning of the previous line
            if self.fh.tell() > 0:
                self.fh.seek(-1, 1)

            # if the last state read was the first state in the file,
            # then we can't access the nth previous state
            else:
                return None

        self.seek_line_start()

        try:
            return self.next()
        except StopIteration:
            return None

    def current_state(self):
        '''Search for the start of the last line in the file, and
        instantiate a ZoneState object based on the contents of that line.'''

        # seek to the end of the file
        self.fh.seek(0, 2)

        return self.previous(0)

    def write_state(self, state):
        '''Append the given zone state to the end of the log file.'''

        if state.unsigned_serial is None:
            unsigned_serial = ''
        else:
            unsigned_serial = str(state.unsigned_serial)

        self.fh.seek(0, 2)
        self.fh.write('%s|%s|%s|%d|%s|%s|%s|%s|%s|%s|%s\n' % \
                (state.name,
                    time.strftime('%Y%m%d%H%M%S', time.gmtime(time.mktime(state.start))),
                    time.strftime('%Y%m%d%H%M%S', time.gmtime(time.mktime(state.expire))),
                    state.serial,
                    unsigned_serial,
                    ','.join(state.active_zsks),
                    ','.join(state.published_zsks),
                    ','.join(state.unpublished_zsks),
                    ','.join(state.active_ksks),
                    ','.join(state.published_ksks),
                    ','.join(state.unpublished_ksks)))
        self.fh.flush()

    def key_info(self, key_filename):
        '''Return a tuple of dates'''
        pub_date, active_date = None, None
        state = self.current_state()

        # there could be no states in this file
        if state is None:
            return pub_date, active_date

        curr_active = key_filename in state.active_zsks + state.unpublished_zsks + state.active_ksks + state.unpublished_ksks
        curr_pub = key_filename in state.active_zsks + state.published_zsks +  state.active_ksks + state.published_ksks
        while state is not None and \
                key_filename in state.active_zsks + state.published_zsks + state.unpublished_zsks + \
                                state.active_ksks + state.published_ksks + state.unpublished_ksks:

            # if the key was and is in a published state
            if curr_pub and key_filename in \
                    state.active_zsks + state.published_zsks +  state.active_ksks + state.published_ksks:
                pub_date = state.start
            else:
                curr_pub = False

            # if the key was and is in an active state
            if curr_active and key_filename in \
                    state.active_zsks + state.unpublished_zsks + state.active_ksks + state.unpublished_ksks:
                active_date = state.start
            else:
                curr_active = False

            state = self.previous()

        return pub_date, active_date
