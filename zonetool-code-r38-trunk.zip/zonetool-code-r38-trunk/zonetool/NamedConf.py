# NamedConf.py: Parse a named.conf configuration file
# A "Partially Correct" Parse of named.conf is not enough!
#
# Upstream author: Jason Vas Dias <jvdias@redhat.com>, Aug 2004
# Upstream URL: https://fedorahosted.org/system-config-bind/browser/src/NamedConf.py?rev=20%3Aa79de3445017
#
#    This package is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This package is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License along
#    with this program; if not, write to the Free Software Foundation, Inc.,
#    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#

import sys
import os
import string

try:
    import hashlib
    md5_hash_func = hashlib.md5
except ImportError:
    import md5
    md5_hash_func = md5.new

from util import check_named_conf

class NamedConf:
    
    def directory(self):
        try:
            dir = self.objs['options']['directory'].strip('"').rstrip(os.sep)
            if os.path.isabs(dir):
                return self.chroot + dir
        except KeyError:
            return os.curdir
        return None

    def abs_path(self, path):
        if os.path.isabs(path):
            return self.chroot + path
        else:
            return os.path.join(self.directory(), path)
    
    def zone_origin_class(self, k):                        
        zk=k.split()
        if len(zk) > 1:
            return [ zk[0].strip('"') , zk[1].upper() ]
        else:
            return [ zk[0].strip('"') , "IN" ]

    def zone_origin(self, k):
        return self.zone_origin_class(k)[0]

    def zone_class(self,k):
        return self.zone_origin_class(k)[1]

    def zone_file(self,k,cls='IN',view=None):
        zone=self.get_zone(k,cls,view)

        if zone is None:
            return None

        try:
            file=zone['file']
            file=file.strip('"')
            return self.abs_path(file)
        except KeyError:
            pass

        return None
    
    def zone_key_dir(self,k,cls='IN',view=None):
        zone=self.get_zone(k,cls,view)

        if zone is None:
            return None

        try:
            file=zone['key-directory']
            file=file.strip('"')
            return self.abs_path(file)
        except KeyError:
            pass

        try:
            file=self.objs['options']['key-directory']
            file=file.strip('"')
            return self.abs_path(file)
        except KeyError:
            pass

        return None
    
    def is_dynamic(self,k,cls='IN',view=None):
        zone=self.get_zone(k,cls,view)

        if zone is None:
            return None

        try:
            t = self.zone_type(k,cls,view)
            if t is not None and t.lower() != 'master':
                return False
        except KeyError:
            pass

        try:
            au=zone['allow-update']
            if filter(lambda x: x.lower() != 'none', au.keys()):
                return True
            return False
        except KeyError:
            pass

        try:
            up=zone['update-policy']
            if filter(lambda x: x.lower() == 'grant', up.keys()):
                return True
            return False
        except KeyError:
            pass

        try:
            au=self.objs['options']['allow-update']
            if filter(lambda x: x.lower() != 'none', au.keys()):
                return True
        except KeyError:
            return False

    def zone_type(self,k,cls='IN',view=None):
        zone=self.get_zone(k,cls,view)

        if zone is None:
            return None

        try:
            return zone['type']
        except KeyError:
            return None

    def get_zone(self, origin, cls='IN', view=None):
        # canonicalize the origin and class
        origin = origin.lower().strip('.')+'.'
        cls = cls.upper()
        try:
            return self.zones[origin][(cls, view)]
        except KeyError:
            return None

    def extract_zones(self):
        self.zones = {}

        views = [(None,self.objs)]
        try:
            for v in self.objs['view'].keys():
                views.append((v.strip('"'),self.objs['view'][v]))
        except KeyError:
            pass

        for v,objs in views:
            try:
                for z in objs['zone'].keys():
                    o = self.zone_origin(z).lower().strip('.')+'.'
                    c = self.zone_class(z).upper()
                    if not self.zones.has_key(o):
                        self.zones[o] = {}
                    self.zones[o][(c,v)] = objs['zone'][z]
            except KeyError:
                pass

    def parse( self, objs ):
        inLineComment=0
        inMultiLineComment=0
        inString=0
        token=''
        tokens=[]
        keys=[]
        keyCounts=[]
        p=''
        end=0
        begin=0
        first_tok=0
        last_tok=0
        obj=objs
        id=''
        first_tok=0
        controlKey=None
        for c in self.contents[:]:            
            if (inString==0) and (inLineComment==0) and (inMultiLineComment==0) and (((c=='/') and (p=='/')) or ( (c == '#') and (p != '\\' ))):
               inLineComment=1
               if c == '/':
                   token=token[:-1]
               if len(token) > 0:
                   tokens.append(token)
               begin=end
               end+=1
               token=''
               continue
            if (inLineComment==1) and (c=='\n') and (p != '\\'):
               inLineComment = 0
               begin=end
               end+=1
               token=''
               continue
            if (inString==0) and (inMultiLineComment==0) and (inLineComment==0) and (p=='/') and (c=='*'):
               inMultiLineComment=1
               if len(token)>1:
                   tokens.append(token[:-1])
               begin=end
               end+=1
               token=''
               continue
            if (inString==0) and (inMultiLineComment==1) and (inLineComment==0) and  (p=='*') and (c=='/'):
               inMultiLineComment=0
               begin=end
               end+=1
               token=''
               continue
            if (c=='"') and (p != '\\') and not(inMultiLineComment or inLineComment):
               inString=not inString            
            if (inMultiLineComment==0) and (inLineComment==0) and (inString==0) and (c in ['\n',' ','\t',';','{','}']):
               # end of non-comment not-in-string token:
               if len(token):
                   tokens.append(token)
                   self.tokens.append({'t': token, 'b': begin, 'e': end})
                   token=''
               if c == '{' :
                   if len(tokens) > 1:
                       key=string.join(tokens[1:],' ')
                       id=tokens[0].lower()
                   elif len(tokens):
                       key=tokens[0].lower()
                       id=''
                   else:
                       # embedded ACLs are legal (eg. 'acl test { {localhost; localnets}; };' )
                       key=''
                       id=''
                   obj=objs
                   for k in keys[:]:
                       obj=obj[k]
                   if len(id):
                       if not obj.has_key(id):
                           obj[id]={}
                       #print c, id, '->', key
                       if len(keys) and (keys[0] == 'controls'):
                           # allow controls to break one '{...}' per ';' rule
                           controlKey = [id,key]
                       else:
                           controlKey = None
                       obj[id][key]={}#{'_t':tokens}
                       obj=obj[id][key]
                       keys.append(id)
                       keys.append(key)
                       keyCounts.append(2)
                   else:
                       #print '{', key
                       if len(keys) and (keys[0] == 'controls'):
                           # allow controls to break one '{...}' per ';' rule
                           if controlKey != None:
                               ckc=0
                               for ck in controlKey:
                                   keys.append(ck)
                                   ckc+=1
                                   obj = obj[ck]
                               keyCounts.append(ckc+1)                               
#                          print 'CONTROLS NEW KEY:',key
                           keys.append(key)
                       else:
                           keys.append(key)
                           keyCounts.append(1)
                       if( type(obj) == list ):
                           # embedded ACLs only
                           obj.append({})
                           obj=obj[-1]
                       elif not obj.has_key(key):
                           obj[key]={}#{'_t':tokens}
                           obj=obj[key]
                       else:
                           # embedded ACLs only
                           if( type(obj[key]) != list ):
                               obj[key]= [ obj[key] ]
                           obj[key].append({})                       
                           obj=obj[key][-1]
                   for i in range((len(self.tokens) - len(tokens)), len(self.tokens)):                       
                       self.tokens[i]['keys']=keys[:]
                       self.tokens[i]['type']='key'
                   tokens=[]
                   id=''
               elif c == '}' :
                   i=keyCounts.pop()
                   while (i>0):
                       #print c, ':',keys.pop()
                       keys.pop()
                       i-=1
                   obj=objs
                   for k in keys[:]:
                       obj=obj[k]
                   tokens=[]
               elif (c == ';') and (len(tokens)):
                   joined=False
                   if len(tokens) > 1:
                       if len(tokens) > 2:                           
                           val=tokens[1:]                               
                       else:
                           val=tokens[1]                           
                           if (len(val)>1) and  (val[0] != '"') and (val[-1] != '"'):
                               val=val.lower()
                       if( len(tokens) > 1):
                           for t in tokens:
                               # ACLs only!
                               if (t[0] in '!/') or (t[-1] in '!/'):
                                   joined=True
                           if joined :
                               val=None
                       for i in range((len(self.tokens) - len(tokens)) + 1, len(self.tokens)):
                           self.tokens[i]['keys']=keys[:]
                           if not joined:
                               self.tokens[i]['keys'].append(tokens[0].lower())
                               self.tokens[i]['type']='val'
                           else:
                               self.tokens[i]['keys'].append(string.join(tokens,''))
                               self.tokens[i]['type']='key'
                       i=(len(self.tokens) - len(tokens))                           
                   else:
                       i=len(self.tokens)-1
                       val=None
                   k=tokens[0].lower()
                   if joined:
                       k = string.join(tokens,'').lower()
                       val=None
                   self.tokens[i]['keys']=keys[:]
                   self.tokens[i]['keys'].append(k)
                   self.tokens[i]['type']='key'
                   if( type(obj) == list):
                       # embedded ACLs only
                       obj=obj[-1]
                   if obj.has_key(k):
                       if len(keys) and (keys[0] == 'trusted-keys') and (type(obj[k])==list) and (type(val)==list):
                           if type(obj[k][0]) != list:
                               obj[k]=[obj[k]]
                           obj[k].append(val)
                       else:
                           if type(obj[k]) != list :
                               obj[k]=[obj[k]]
                           obj[k].append(val)
                       if len(tokens) > 1:
                           for i in range((len(self.tokens) - len(tokens)) + 1, len(self.tokens)):
                               self.tokens[i]['i']=len(obj[k])
                   else:
                       obj[k]=val
                   if k == 'include':
                       self.includes.append((val, obj))
                   tokens=[]
               begin=end
            elif (inMultiLineComment==0) and (inLineComment==0):
               token += c            
            end+=1
            p=c
    
    def read(self, named_conf, objs):
        try:
            fd = os.open(named_conf, os.O_RDONLY)
            s = os.fstat(fd)
            self.contents = os.read(fd, s.st_size)        
            os.close(fd)
        except OSError, e :
            return e
        self.parse(objs)
        return 0

    def load(self, named_conf):
        self.errors=[]
        self.files=[]
        self.objs={}
        self.includes=[]
        check_named_conf(named_conf, self.chroot)
        self.files.append({'file':self.chroot + named_conf,'tokens':[],'contents':''})
        self.tokens=self.files[0]['tokens']
        self.contents=''
        self.read(self.files[0]['file'], self.objs)
        if self.includes:
            i=0
            n=0
            j=0
            while n < len( self.includes ):
                n = len( self.includes )
                includes = self.includes[j:n]
                for f,objs in includes:
                    self.files[i]['contents']=self.contents
                    self.files[i]['md5']=md5_hash_func(self.contents).digest()
                    self.contents=''
                    fn = f.strip('"')
                    if os.path.isabs(fn):
                        fn = self.chroot + fn
                    else:
                        fn = os.path.join(self.directory(), fn)
                    self.files.append({'file': fn,'tokens':[],'contents':''})
                    i=i+1
                    self.tokens = self.files[i]['tokens']
                    e = self.read(self.files[i]['file'], objs)
                    if e != 0:
                        self.errors=e[1]
                        return e
                j=n
            self.tokens=self.files[0]['tokens']
            self.files[i]['contents']=self.contents
            self.files[i]['md5']=md5_hash_func(self.contents).digest()
            self.contents=self.files[0]['contents']
        else:
            self.files[0]['contents']=self.contents
            self.files[0]['md5'] = md5_hash_func(self.contents).digest()
        return 0

    def key_files(s):
        keys=[]
        keyFiles=[]
        if len(s.files) <= 1:
            return keyFiles
        for f in s.files[1:]:
            keyFile = f
            for t in f['tokens']:
                if t['keys'][0] != 'key':
                    keyFile = None
                    keys=[]
                    break
                if (len(keys)==0) or (t['keys'][1] != keys[-1]):
                    keys.append(t['keys'][1])
            if (keyFile != None) and len(keys):
                for k in keys:
                    keyFiles.append([k,f])
        return keyFiles
    
    def __init__(self, named_conf=None, chroot=''):
        self.objs={}
        self.zones={}
        self.contents=''
        self.tokens=[]
        self.files=[]
        self.errors=[]
        self.chroot=chroot.rstrip(os.sep)
        self.load(named_conf)
        self.extract_zones()

if __name__ == "__main__":
    nmdc=NamedConf()
    if len(nmdc.errors):
        print  "Errors: ",nmdc.errors
        sys.exit(-1)
