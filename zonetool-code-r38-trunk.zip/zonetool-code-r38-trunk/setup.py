#!/usr/bin/env python

from distutils.core import setup
import glob
import os
import shutil
import sys

vars = {}

def set_distribution_defaults():
    if sys.prefix.rstrip(os.sep) == '/usr':
        etc_dir = '/etc'
    else:
        etc_dir = os.path.join(sys.prefix, 'etc')

    vars['named_user'] = 'named'
    vars['named_group'] = 'named'
    vars['zonetool_cfg'] = os.path.join(etc_dir, 'zonetool','zonetool.cfg')
    vars['zonetool_dir'] = '/var/lib/zonetool'
    vars['named_conf'] = '/etc/named.conf'
    vars['syslog_facility'] = 'user'

    if os.uname()[0] == 'Linux':
        if os.path.exists('/etc/debian_version'):
            vars['named_user'] = 'bind'
            vars['named_group'] = 'bind'
            vars['zonetool_dir'] = '/var/lib/zonetool'
            vars['named_conf'] = '/etc/bind/named.conf'
        elif os.path.exists('/etc/redhat-release'):
            vars['named_user'] = 'named'
            vars['named_group'] = 'named'
            vars['zonetool_dir'] = '/var/lib/zonetool'
            vars['named_conf'] = '/etc/named.conf'
    elif os.uname()[0] == 'FreeBSD':
        vars['named_user'] = 'bind'
        vars['named_group'] = 'bind'
        vars['zonetool_dir'] = '/var/db/zonetool'
        vars['named_conf'] = '/etc/namedb/named.conf'

def apply_distribution_defaults(filename):
    assert filename.endswith('.in'), 'Filename supplied for customization must end with \'.in\': %s' % (filename)

    filename_out = filename[:-3]
    in_fh = open(filename, 'r')
    out_fh = open(filename_out, 'w')
    for line in in_fh:
        line = line.replace('ZT_DEFAULT_NAMED_USER', vars['named_user'])
        line = line.replace('ZT_DEFAULT_NAMED_GROUP', vars['named_group'])
        line = line.replace('ZT_DEFAULT_ZONETOOL_CFG', vars['zonetool_cfg'])
        line = line.replace('ZT_DEFAULT_ZONETOOL_DIR', vars['zonetool_dir'])
        line = line.replace('ZT_DEFAULT_NAMED_CONF', vars['named_conf'])
        line = line.replace('ZT_DEFAULT_SYSLOG_FACILITY', vars['syslog_facility'])
        out_fh.write(line)
    in_fh.close()
    out_fh.close()

def file_list(dir,pattern):
    return filter(lambda x: os.path.isfile(x) and \
            not x.endswith('.in') and \
            not x.startswith('.'),
            glob.glob(os.path.join(dir,pattern)))

set_distribution_defaults()
apply_distribution_defaults(os.path.join('zonetool','settings.py.in'))
apply_distribution_defaults(os.path.join('doc','examples','zonetool.cfg.in'))

setup(name='zonetool',
      version='0.11.4',
      description='DNS zone signing and key management utilities.',
      long_description='''zonetool maintains signed DNSSEC zones and keys.  It simplifies DNSSEC key
maintenance by using minimal configuration files and tracking "state" of signed
zones.  Zonetool is capable of effectively handling ZSK and KSK rollovers.  It
resilient to interruption.''',
      author='Casey T. Deccio',
      author_email='ctdecci@sandia.gov',
      packages=['zonetool'],
      scripts=['bin/zonetool'],
      data_files=[
          ('share/doc/zonetool', ['README', 'COPYING'] + \
                  file_list(os.path.join('doc'), '*.png') + \
                  file_list(os.path.join('doc'), '*.html')),
          ('share/doc/zonetool/examples', file_list(os.path.join('doc','examples'), '*')),
          (vars['zonetool_dir'],[]),
          ],
      )
